	//=================== Screen Name = Object_16427_020821140852879====================== 
	public void Click_Object_16427_020821140852879_16425(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16427_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Platforms')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16428_020821140852879_16426(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16428_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Platforms')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16429_020821140852879_16427(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16429_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Platforms')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16430_020821140852879_16428(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16430_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Platforms')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16431_020821140852879_16429(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16431_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Platforms')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16432_020821140852879_16430(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16432_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Qnowledge')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16433_020821140852879_16431(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16433_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Qnowledge')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16434_020821140852879_16432(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16434_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Training')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16435_020821140852879_16433(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16435_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Industries')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16436_020821140852879_16434(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16436_020821140852879"; 
		String str_ObjectName = "(//a[contains(text(),'Contact Us')])[2]"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16437_020821140852879_16435(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16437_020821140852879"; 
		String str_ObjectName = "firstname"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxObject_16438_020821140852879_16436(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxObject_16438_020821140852879"; 
		String str_ObjectName = "firstname"; 
		String str_Class = "seltext"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16439_020821140852879_16437(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16439_020821140852879"; 
		String str_ObjectName = "email1"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxObject_16440_020821140852879_16438(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxObject_16440_020821140852879"; 
		String str_ObjectName = "email1"; 
		String str_Class = "seltext"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16441_020821140852879_16439(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16441_020821140852879"; 
		String str_ObjectName = "phone"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16442_020821140852879_16440(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16442_020821140852879"; 
		String str_ObjectName = "email1"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16443_020821140852879_16441(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16443_020821140852879"; 
		String str_ObjectName = "subject"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxObject_16444_020821140852879_16442(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxObject_16444_020821140852879"; 
		String str_ObjectName = "subject"; 
		String str_Class = "seltext"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16445_020821140852879_16443(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16445_020821140852879"; 
		String str_ObjectName = "phone"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16446_020821140852879_16444(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16446_020821140852879"; 
		String str_ObjectName = "firstname"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16447_020821140852879_16445(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16447_020821140852879"; 
		String str_ObjectName = "firstname"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16448_020821140852879_16446(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16448_020821140852879"; 
		String str_ObjectName = "firstname"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16449_020821140852879_16447(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16449_020821140852879"; 
		String str_ObjectName = "//form[@id='main-contact1-form']/div"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxObject_16450_020821140852879_16448(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxObject_16450_020821140852879"; 
		String str_ObjectName = "email1"; 
		String str_Class = "seltext"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16451_020821140852894_16449(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16451_020821140852894"; 
		String str_ObjectName = "phone"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxObject_16452_020821140852894_16450(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxObject_16452_020821140852894"; 
		String str_ObjectName = "phone"; 
		String str_Class = "seltext"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16453_020821140852894_16451(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16453_020821140852894"; 
		String str_ObjectName = "//form[@id='main-contact1-form']/div"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxObject_16454_020821140852894_16452(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxObject_16454_020821140852894"; 
		String str_ObjectName = "subject"; 
		String str_Class = "seltext"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_Object_16455_020821140852894_16453(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Object_16455_020821140852894"; 
		String str_ObjectName = "message"; 
		String str_Class = "selclick"; 
		String str_Event = "CLICK"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxObject_16456_020821140852894_16454(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxObject_16456_020821140852894"; 
		String str_ObjectName = "message"; 
		String str_Class = "seltext"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	//=================== Screen Name = FunctionCall====================== 
	public void Verify_Map_Title_17866(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
	} 
	//=================== Screen Name = Add_Employee====================== 
	public void Verify_Map_Data_17867(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Verify_Map_Data"; 
		String str_ObjectName = "firstName"; 
		String str_Class = "seltext"; 
		String str_Event = "EXIST"; 
		String str_Property = "ID"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	//=================== Screen Name = Login====================== 
	public void Click_Click_Submit_21493(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Click_Submit"; 
		String str_ObjectName = "//[text(),Submit]"; 
		String str_Class = "selCLICK"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	//=================== Screen Name = Login====================== 
	public void Click_Click_Submit_21494(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_Click_Submit"; 
		String str_ObjectName = "//[text(),Submit]"; 
		String str_Class = "selCLICK"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void BUSKeyword_290121114047 (int p_Iteration)
	{
		try {
			Click_Object_14639_290121114047633_14637 ("3203","",0);
			textBoxObject_14640_290121114047636_14638( "3203", "14638",p_Iteration);
			textBoxObject_14641_290121114047636_14639( "3203", "14639",p_Iteration);
			textBoxObject_14642_290121114047636_14640( "3203", "14640",p_Iteration);
			textBoxObject_14643_290121114047636_14641( "3203", "14641",p_Iteration);
		}
		catch (Exception e) {
			cl.Loggerupdator("Business Keyword BUSKEYWORD_290121114047 is not performed","BUSKeyword_290121114047",0,e.toString());
		}
	public void BUSKeyword_020821020926 (int p_Iteration)
	{
		try {
			Click_Object_16427_020821140852879_16425 ("3527","",0);
			Click_Object_16428_020821140852879_16426 ("3527","",0);
			Click_Object_16429_020821140852879_16427 ("3527","",0);
			Click_Object_16430_020821140852879_16428 ("3527","",0);
			Click_Object_16431_020821140852879_16429 ("3527","",0);
			Click_Object_16432_020821140852879_16430 ("3527","",0);
			Click_Object_16433_020821140852879_16431 ("3527","",0);
			Click_Object_16434_020821140852879_16432 ("3527","",0);
			Click_Object_16435_020821140852879_16433 ("3527","",0);
			Click_Object_16436_020821140852879_16434 ("3527","",0);
			Click_Object_16437_020821140852879_16435 ("3527","",0);
			textBoxObject_16438_020821140852879_16436( "3527", "16436",p_Iteration);
			Click_Object_16439_020821140852879_16437 ("3527","",0);
			textBoxObject_16440_020821140852879_16438( "3527", "16438",p_Iteration);
			Click_Object_16441_020821140852879_16439 ("3527","",0);
			Click_Object_16442_020821140852879_16440 ("3527","",0);
			Click_Object_16443_020821140852879_16441 ("3527","",0);
			textBoxObject_16444_020821140852879_16442( "3527", "16442",p_Iteration);
			Click_Object_16445_020821140852879_16443 ("3527","",0);
			Click_Object_16446_020821140852879_16444 ("3527","",0);
			Click_Object_16447_020821140852879_16445 ("3527","",0);
			Click_Object_16448_020821140852879_16446 ("3527","",0);
			Click_Object_16449_020821140852879_16447 ("3527","",0);
			textBoxObject_16450_020821140852879_16448( "3527", "16448",p_Iteration);
			Click_Object_16451_020821140852894_16449 ("3527","",0);
			textBoxObject_16452_020821140852894_16450( "3527", "16450",p_Iteration);
			Click_Object_16453_020821140852894_16451 ("3527","",0);
			textBoxObject_16454_020821140852894_16452( "3527", "16452",p_Iteration);
			Click_Object_16455_020821140852894_16453 ("3527","",0);
			textBoxObject_16456_020821140852894_16454( "3527", "16454",p_Iteration);
		}
		catch (Exception e) {
			cl.Loggerupdator("Business Keyword BUSKEYWORD_020821020926 is not performed","BUSKeyword_020821020926",0,e.toString());
		}
	}
	public void BUS_Login_55 (int p_Iteration)
	{
		try {
			textBoxLogin_UserName_600( "94", "600",p_Iteration);
			textBoxLogin_Password_601( "94", "601",p_Iteration);
			Click_Login_Ok_602 ("94","",0);
			Verify_Map_Title_17866( "4620", "17866",p_Iteration);
		}
		catch (Exception e) {
			cl.Loggerupdator("Business Keyword BUS_LOGIN_55 is not performed","BUS_Login_55",0,e.toString());
		}
	}
	public void BUS_LOGIN (int p_Iteration)
	{
		try {
			textBoxLogin_UserName_600( "94", "600",p_Iteration);
			textBoxLogin_Password_601( "94", "601",p_Iteration);
			Click_Login_Ok_602 ("94","",0);
		}
		catch (Exception e) {
			cl.Loggerupdator("Business Keyword BUS_LOGIN is not performed","BUS_LOGIN",0,e.toString());
		}
	}
	}
