package SeleniumProject;
import SeleniumProject.CommonLibrary;
import org.openqa.selenium.*;
public class IMDA_Demo_2546_ApplicationLibrary extends SeleniumProject
{
	private static WebElement element = null;
	CommonLibrary cl =new CommonLibrary();
	//================================================================================================== 
	// Library Name    :  ApplicationKeywordsLibrary.java 
	// Library Version :  V_0.1
	// Creation Date   :  4/12/2022 10:30:32 AM
	// Created By      :  NT AUTHORITY\SYSTEM
	//================================================================================================== 

	//=================== Screen Name = Public Site====================== 
	public void Click_LOGIN_IN_PS_21561(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_LOGIN_IN_PS"; 
		String str_ObjectName = "//button[contains(text(),'Login')]"; 
		String str_Class = "selCLICK"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxENTER_EMAIL_21562(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxENTER_EMAIL"; 
		String str_ObjectName = "email"; 
		String str_Class = "selTEXT"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "NAME"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void textBoxENTER_PASSWORD_21563(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "textBoxENTER_PASSWORD"; 
		String str_ObjectName = "//*[@type='password']"; 
		String str_Class = "selTEXT"; 
		String str_Event = "SETTEXT"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void Click_LOGIN_IN_LOGIN_21564(String p_ScreenID,String p_ObjectID,int p_DataIteration) 
	{ 
		String str_KeywordName = "Click_LOGIN_IN_LOGIN"; 
		String str_ObjectName = "//*[contains(text(),'Login')]"; 
		String str_Class = "selCLICK"; 
		String str_Event = "CLICK"; 
		String str_Property = "XPATH"; 
		cl.Func_MainNew (p_ScreenID , str_ObjectName , str_Class , str_Event , p_ObjectID , p_DataIteration , str_KeywordName,str_Property); 
	} 
	public void BUS_IMDA_Login (int p_Iteration)
	{
		try {
			Click_LOGIN_IN_PS_21561 ("5699","",0);
			textBoxENTER_EMAIL_21562( "5699", "21562",p_Iteration);
			textBoxENTER_PASSWORD_21563( "5699", "21563",p_Iteration);
			Click_LOGIN_IN_LOGIN_21564 ("5699","",0);
		}
		catch (Exception e) {
			cl.Loggerupdator("Business Keyword BUS_IMDA_LOGIN is not performed","BUS_IMDA_Login",0,e.toString());
		}
	}
} 
