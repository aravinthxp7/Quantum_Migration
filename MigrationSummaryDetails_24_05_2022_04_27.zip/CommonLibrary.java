package SeleniumProject;

import java.util.List;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.text.DateFormat;
import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.google.common.io.CharStreams;
import org.openqa.selenium.ContextAware;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.awt.*;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileDriver;

import org.openqa.selenium.winium.DesktopOptions; // Don't command this line instead of add this  jar file \\10.138.80.50\Bank\QRator\new_Referrens for falcon
import org.openqa.selenium.winium.WiniumDriverService; // Don't command this line instead of add this  jar file \\10.138.80.50\Bank\QRator\new_Referrens for falcon
import org.openqa.selenium.winium.WiniumDriver; // Don't command this line instead of add this  jar file \\10.138.80.50\Bank\QRator\new_Referrens for falcon

import io.appium.java_client.android.HasSupportedPerformanceDataType;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class CommonLibrary extends SeleniumProject {

	public static AppiumDriver<AndroidElement> AndroidDriver = null;
	public static IOSDriver<IOSElement> IOSdriver = null;
	public static int TimestampHeaderCount = 1;
	public static java.util.Date date = null;
	public static java.sql.Timestamp timeStamp = null;
	public static Map<String, String> map = new HashMap<String, String>();
	static Map<String, String> TestStepDesc = new HashMap<String, String>();
	static Map<String, String> TestStepObjectEnDisable = new HashMap<String, String>();
	static List<String> TestStepListED = new ArrayList<String>();
	public static String[] ArrIterations;
	public static String tsStatus = ""; 
	public static String tcStatus = "Pass"; 
	public static String pub_TDEnvID = "";
	public static String pub_BuildNo = "";
	public BufferedWriter output;
	public BufferedWriter IterationOutput;
	public BufferedWriter outputNew;
	public BufferedWriter IterationOutputNew;
	public static int sno = 0; // For every iteration, reset the test step count
	public static int pub_UserID = 0;
	public static String LinkText = "";
	public static int pub_ReleaseId = 0;
	public static int pub_CycleId = 0;
	public static String packageName = "";
	public static String pubTestCaseName = "";
	public static String pubTestCaseID = "";
	public static String PubApplicationName = "";
	public static String PubApplicationID = "";
	public static String Pub_BrowserName = "";
	public static int Pub_ExecutionRequestId = 0;
	public static String ClientID = "";
	public static String useCaseName = "";
	public static int iteration = 1;
	public static int Cur_UserID = 0;
	public static int pub_testsets = 0;
	String applicationURL = "";
	String continueOnFail = "";
	public static String BrowserType = "";
	String baseResultPath = "";
	static String ResultCyclepath = "";
	static String tcResultFolder = "";
	public static String testCaseResultPath = "";
	public static String testCaseIterationResultPath = "";
	public static int Env_TestcaseExecutionID = 0;
	public static int Itera_Count = 0;
	public static String Retrieve_Total_Iteration;
	public static String pub_Cur_Iteration;

	public static String pub_getTestcaseStatus = "Passed";
	public static String pub_getIterationStatus = "Passed";
	static int IterationCount = 0;
	public static String parentHandle = "";
	public static int Window_count = 0;
	public static File Result1 = null;
	public static File Result2 = null;
	public static File Result3 = null;
	public static File Result4 = null;
	public static String TestcaseFinalStatus = "Pass";
	public static int run_ios = 0;
	public static String ActualTestDataValue = "";
	public static int pub_EnvValue = 10;
	public static int pub_TestcaseWaitTime = 0;
	public static String ExitFlag = "false";
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date1 = new Date();
	public static String BrowserTypeResult = "";
	public static Logger log = Logger.getLogger("devpinoyLogger");

	public static String BrowserRequired = "Y";
	public static String Dynamic_TestValue = "";
	public static int callfolderOnce = 0;
	public static String Pub_dynamicValue = "";
	public static String Pub_DefaultBrowserName = "";
    public static String pub_EnvName = "";
	public static int pub_IsIntegrationTC = 0;
	public static String pub_Env_ID = "";
	public static int pub_IntegrationID = 0;
	public static String pub_IntegrationGrpName = "";
	public static int pub_SubModuleID = 0;
	public static String pub_SubModuleName = "";
	public static int Env_ScreenShotFlag = 1;

	// added by ios
	public static String DeviceName = "";
	public static String DeviceIP = "";
	public static String DevicePort = "";
	public static String DeviceVersion = "";
	public static String host = "";
	public static String DevicePlatForm = "";
	public static String DeviceID = "";
	public static String DeviceUDID = "";
	public static String ProductID = "";
	public static String RiderID = "0";
	public static String App_Package = "";
	public static String App_Activity = "";
	public static String WDA_Port = "";
	public static String Bundle_ID = "";
	public static String Sys_Port = "";
	
	public static double _CPU_Min = 0;
	public static double _CPU_Max;
	public static double _Network_Up = 0;
	public static double _Networ_Down = 0;
	public static double _Battery_Min = 0;
	public static double _Battery_Max = 0;
	public static double _Mem_Heap = 0;
	public static double _Mem_Heap_1 = 0;
	
	//cloud congig
	public static String Sauce_Username="";
	public static String Accesskey="";
	public static String Apppath="";
	public static String Orienation="";
	public static String Appiumversion="";
	public static String Datacenter="";
	public static String Cloudtype="";
	public static String TestApi="";
	public static String Devicelocation="";
	public static String app_name="";
	
	//Host address
	public static String Apiservice="";
	public static Future<Integer> ResultWorker;
	public static Future<Integer> DBWorker;
	
	
	 Map<String, String> varDictRiderWithValue = new HashMap<String, String>();
	 Map<String, String> varDictRiderWithTestcase = new HashMap<String, String>();
	 Map<String, String> varDictRiderWithIteration = new HashMap<String, String>();
	 Map<String, String> varDictRiderWithAppID = new HashMap<String, String>();
	 
	 
	// Added New for Sub Flow Process
	public static int _ItsSubFlowTC = 0;
	public static Map<String, String> _subFlowTestData = new HashMap<String, String>();
	public static Map<String, String> _subFlowTestDescription = new HashMap<String, String>();

	public static String pubSubTestCaseName = "";
	public static String pubSubTestCaseID = "";
	public static String pubSubTestScript = "";
	
	
	// added new for Rider cases

	public static String varRiderTestCaseName = "";
	public static String varRiderTestCaseID = "";
	public static String varRiderIteration = "";
	public static Map<String, String> _Ridertestdata = new HashMap<String, String>();
	public static Map<String, String> _RiderTestStepDesc = new HashMap<String, String>();
	public static int _ItsRiderFlowTC=0;	
	String Terminaltype = "";

	// Assign driver to selected browser
	public void openTestNG(String browser, String Iteration) {
		callfolderOnce = 1;
		BrowserTypeResult = browser;
		Retrieve_Total_Iteration = Iteration;
		try {
			IterationCount = 0;
			pub_getTestcaseStatus = "Passed";
			pub_getIterationStatus = "Passed";
			TestcaseFinalStatus = "Pass";		
			/******************************************************************************************************************/		
			
			Loggerupdator("Driver assign to  browser  : ","openTestNG" + browser,2,"");
			
			if (browser.equalsIgnoreCase("firefox")) {
				
				Pub_DefaultBrowserName="firefox";
				String driverpath=GetExecutablepath("firefox");
				System.setProperty("webdriver.gecko.driver", driverpath);
				DesiredCapabilities capabilities = DesiredCapabilities.firefox();
				capabilities.setCapability("marionette", true);
				driver = new FirefoxDriver(capabilities);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Loggerupdator("**Firefox Remote WebDriver Connected  : ","openTestNG" + browser,2,"");

			} else if (browser.equalsIgnoreCase("chrome")) {
				Pub_DefaultBrowserName="chrome";
				String driverpath=GetExecutablepath("chrome");
				System.setProperty("webdriver.chrome.driver", driverpath);				
				driver = new ChromeDriver();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Loggerupdator("**Chrome Remote WebDriver Connected  : ","openTestNG" + browser,2,"");
			} else if (browser.equalsIgnoreCase("IExplore")) {
				
				String driverpath=GetExecutablepath("IExplore");
				Pub_DefaultBrowserName="IExplore";
				System.setProperty("webdriver.ie.driver", driverpath);
				DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
				capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
						true);
				capabilities.setCapability("ignoreProtectedModeSettings", true);
				driver = new InternetExplorerDriver(capabilities);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Loggerupdator("**IExplore Remote WebDriver Connected  : ","openTestNG" + browser,2,"");

			} else if (browser.equalsIgnoreCase("edge")) {
				Pub_DefaultBrowserName="edge";
				String Node = "http://172.16.1.70:5555/wd/hub";
				DesiredCapabilities cap = DesiredCapabilities.safari();
				driver = new RemoteWebDriver(new URL(Node), cap);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				Loggerupdator("**edge Remote WebDriver Connected  : ","openTestNG" + browser,2,"");

			} else if (browser.equalsIgnoreCase("WinApp")) {
				driver = null;
				String driverpath=GetExecutablepath("WinApp");
				Pub_DefaultBrowserName = "Winapp";
				Runtime rt = Runtime.getRuntime();
				String processname = "cmd.exe /k cd\\ & cd "+driverpath+" & Winium_Desktop_Driver.exe --port 8888";
				Process pr = rt.exec(processname);
				DesktopOptions options = new DesktopOptions();
				options.setApplicationPath("C:\\frnroot\\vic.exe");
				driver = new WiniumDriver(new URL("http://localhost:8888"), options);
				Loggerupdator("**WinApp Driver Connected  : ","openTestNG" + browser,2,"");

			} else if (browser.equalsIgnoreCase("IOS")) {
				Pub_DefaultBrowserName = "IOS";			
				update_device_status(1, DeviceID); // Ios Starting status

			} else if (browser.equalsIgnoreCase("Android")) {
				Pub_DefaultBrowserName = "Android";				
				update_device_status(1, DeviceID);
			}
			else if (browser.equalsIgnoreCase("Terminal")) {
				Pub_DefaultBrowserName = "Terminal";								
			}
		} catch (Exception ex) {
			Loggerupdator("Could not get Driver connection","openTestNG" + browser,0,ex.toString());
		}
	}

	private String GetExecutablepath(String browser) {
		String Executablepath = "";
		String path="";
		
		try {

			switch (browser.toUpperCase().trim()) {

			case "CHROME":

				path = new File(getClass().getProtectionDomain().getCodeSource().getLocation().getPath()).toString();
				path = URLDecoder.decode(path, "UTF-8");
				path = path.replaceAll("file:/", "");
				path = path.replaceAll("\\u0020", "\\ ");
				Executablepath = path.replace("\\SeleniumProject", "").replace("\\classes", "").replace("\\Automation", "") + "\\Reference\\chromedriver.exe";
				//Executablepath ="C:\\Reference\\chromedriver.exe";
				break;

			case "FIREFOX":

				path = new File(getClass().getProtectionDomain().getCodeSource().getLocation().getPath()).toString();
				path = URLDecoder.decode(path, "UTF-8");
				path = path.replaceAll("file:/", "");
				path = path.replaceAll("\\u0020", "\\ ");
				Executablepath = path.replace("\\SeleniumProject", "").replace("\\classes", "").replace("\\Automation", "") + "\\Reference\\geckodriver.exe";
				
				break;

			case "IEXPLORE":
				path = new File(getClass().getProtectionDomain().getCodeSource().getLocation().getPath()).toString();
				path = URLDecoder.decode(path, "UTF-8");
				path = path.replaceAll("file:/", "");
				path = path.replaceAll("\\u0020", "\\ ");
				Executablepath = path.replace("\\SeleniumProject", "").replace("\\classes", "").replace("\\Automation", "") + "\\Reference\\IEDriverServer.exe";			
				break;
				
			case "WINAPP":
				    path = new File(getClass().getProtectionDomain().getCodeSource().getLocation().getPath()).toString();
					path = URLDecoder.decode(path, "UTF-8");
					path = path.replaceAll("file:/", "");
					path = path.replaceAll("\\u0020", "\\ ");
					Executablepath = path.replace("\\SeleniumProject", "").replace("\\classes", "").replace("\\Automation", "") + "\\Reference";
				  break;
				
			case "ENVIRONMENT":
				path = new File(getClass().getProtectionDomain().getCodeSource().getLocation().getPath()).toString();
				path = URLDecoder.decode(path, "UTF-8");
				path = path.replaceAll("file:/", "");
				path = path.replaceAll("\\u0020", "\\ ");
				Executablepath = path.replace("\\SeleniumProject", "").replace("\\classes", "")+"\\config\\FunctionalLibrary\\EnvironmentFile.xml";			
			//	Executablepath ="C:\\Automation\\config\\FunctionalLibrary\\EnvironmentFile.xml";
				break;
				
			case "RiderEnvironment":
				path = new File(getClass().getProtectionDomain().getCodeSource().getLocation().getPath()).toString();
				path = URLDecoder.decode(path, "UTF-8");
				path = path.replaceAll("file:/", "");
				path = path.replaceAll("\\u0020", "\\ ");
				Executablepath = path.replace("\\SeleniumProject", "").replace("\\classes", "")+"\\config\\FunctionalLibrary\\RiderEnvironmentFile.xml";			
							
				break;
				
			case "RiderLib":
				path = new File(getClass().getProtectionDomain().getCodeSource().getLocation().getPath()).toString();
				path = URLDecoder.decode(path, "UTF-8");
				path = path.replaceAll("file:/", "");
				path = path.replaceAll("\\u0020", "\\ ");
				Executablepath = path.replace("\\SeleniumProject", "").replace("\\classes", "")+"\\config\\RiderLibrary.java";			
							
				break;
				
			 default:
			    path = new File(getClass().getProtectionDomain().getCodeSource().getLocation().getPath()).toString();
				path = URLDecoder.decode(path, "UTF-8");
				path = path.replaceAll("file:/", "");
				path = path.replaceAll("\\u0020", "\\ ");
				Executablepath = path.replace("\\SeleniumProject", "").replace("\\classes", "").replace("\\Automation", "");
				break;
			}
		} catch (Exception ex) {
			Loggerupdator("Could not Read Run time classpath","GetExecutablepath",0,ex.toString());

		}

		return Executablepath;
	}

	private boolean Appuploadsauce() {

		try {

			try {
				String extension = "";
				if ((Pub_DefaultBrowserName.equals("IOS"))) {

					if (Apppath.lastIndexOf(".") != -1 && Apppath.lastIndexOf(".") != 0) {
						String temp = Apppath.substring(Apppath.lastIndexOf(".") + 1);
						if (temp.equalsIgnoreCase("ipa")) {
							extension = "ipa";
						} else if (temp.equalsIgnoreCase("zip")) {
							extension = "app";
						}

					}
				} else {
					extension = "apk";
				}
				String response = readcloudstorage(Sauce_Username, Accesskey, app_name + "." + extension);

				if (response.equalsIgnoreCase("false")) {

					String urls = "https://saucelabs.com/rest/v1/storage/" + Sauce_Username + "/" + app_name + "."
							+ extension + "";

					URL url = new URL(urls);
					URLConnection uc = url.openConnection();
					uc.setDoOutput(true);
					uc.setRequestProperty("X-Requested-With", "Curl");
					String userpass = Sauce_Username + ":" + Accesskey;
					String basicAuth = "Basic " + new String(new Base64().encode(userpass.getBytes()));
					uc.setRequestProperty("Authorization", basicAuth);
					OutputStream output = uc.getOutputStream();
					Files.copy(new File(Apppath).toPath(), output);
					output.flush();
					Loggerupdator("Application is uploading to Sauce Storage...", "Appuploadsauce", 1, "");
					try (BufferedReader reader = new BufferedReader(new InputStreamReader(uc.getInputStream()))) {
						String line1;
						while ((line1 = reader.readLine()) != null) {
							System.out.println(line1);
							if (line1.contains(app_name)) {
								System.out.println("Response: " + line1);
								System.out.println("App Upload Sucessfully");
								return true;
							}
						}
					}
				} else if (response.equalsIgnoreCase("Unauthorized")) {

					Loggerupdator("Unauthorized Account,Kindly check your configurations...", "Appuploadsauce", 1, "");
					Thread.sleep(5000);
					update_device_status(0, DeviceID);
					System.exit(0);
				} else if (response.equalsIgnoreCase("error")) {
					Loggerupdator("Could not connect Sauce Server...", "Appuploadsauce", 1, "");
					Thread.sleep(5000);
					update_device_status(0, DeviceID);
					System.exit(0);
				} else {
					Loggerupdator("Application Available on Sauce Storage...", "Appuploadsauce", 1, "");
					return true;
				}
				Loggerupdator("Could not connect Sauce Server...", "Appuploadsauce", 1, "");

				Thread.sleep(5000);
				update_device_status(0, DeviceID);
				System.exit(0);
			} catch (Exception ex) {
				Loggerupdator("Could not upload Application into the  Sauce Storage...", "Appuploadsauce", 1, "");
				update_device_status(0, DeviceID);
				Thread.sleep(5000);
				System.out.println(ex);
			}

		} catch (Exception ex) {
			System.out.println(ex);
			Loggerupdator("Appuploadsauce Failed", "Appuploadsauce", 0, ex.toString());
		}
		return false;
	}
	
	public  String readcloudstorage(String username, String Accesskey, String App) {

		String operSys = System.getProperty("os.name").toLowerCase();
		
		if (operSys.contains("win")) {				

			String result = "";
			try {
				URL url = new URL("https://saucelabs.com/rest/v1/storage/" + username + "");
				URLConnection uc = url.openConnection();
				uc.setRequestProperty("X-Requested-With", "Curl");
				String userpass = username + ":" + Accesskey;
				String basicAuth = "Basic " + new String(new Base64().encode(userpass.getBytes()));
				uc.setRequestProperty("Authorization", basicAuth);
				result = CharStreams.toString(new InputStreamReader(uc.getInputStream()));
				if(result.contains("Unauthorized")){			
			      return "Unauthorized";
				}else{			
					JSONParser jsonParser = new JSONParser();
					org.json.simple.JSONObject tcjson = (org.json.simple.JSONObject) jsonParser.parse(result);

					org.json.simple.JSONArray storgae = (org.json.simple.JSONArray) tcjson.get("files");
					for (int index = 0; index < storgae.size(); index++) {
						org.json.simple.JSONObject object = (org.json.simple.JSONObject) storgae.get(index);
						if (object.containsKey("name")) {
							String appname = object.get("name").toString();				
							if(App.equals(appname)){
								return "true";
							}
						}
					}
				}						
			} catch (Exception ex) {
				Loggerupdator("Exception in readcloudstorage","readcloudstorage",0,ex.toString());
				return "error";				
			}
		}
		return "false";
	}
	// Get connection values from Environment Xml /////
	public void getapihost() {
		try {
				
			String path=GetExecutablepath("Environment");
			File fXmlFile=new File(path);	
		//	fXmlFile = new File("C:\\Automation\\config\\FunctionalLibrary\\EnvironmentFile.xml");
		
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("Variable");			
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {					
					Element eElement = (Element) nNode;
					String Envname = eElement.getElementsByTagName("Name").item(0).getTextContent();						
					 if (Envname.contains("Quantum_URL")) {
						Apiservice = eElement.getElementsByTagName("Value").item(0).getTextContent();
					   break;
					 }
				 }
			}
		} catch (Exception ex) {
			Loggerupdator("Could not get Quantum Api service","getapihost",0,ex.toString());
		}
	}

	public void update_device_status(int id, String deviceID) {

		try {			
			String strQuery = "UPDATE deviceinfo SET deviceRunningstatus = " + id + " WHERE FlatId = " + deviceID + " ";		
			RestApicall(strQuery);
		} catch (Exception e) {
			Loggerupdator("Failed to update device Status","update_device_status",0,e.toString());
			System.out.println(e);
		}
	}
	
	/************************************************************************/
	/** Read the Environment XML File to get the testcase Details and browser/
	/************************************************************************/
	public void Initialization() {
		try {
			log.info("Retrieve Values from Environment File");
			if (sno == 0) {
				log.info("*******************************************************************");
				log.info("Testcase Initialization");
				log.info("*******************************************************************");
				pub_getTestcaseStatus = "Passed";
				getapihost();

				String path=GetExecutablepath("Environment");
				File fXmlFile=new File(path);	
			//	fXmlFile = new File("C:\\Automation\\config\\FunctionalLibrary\\EnvironmentFile.xml");

				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fXmlFile);
				doc.getDocumentElement().normalize();
				String resultpath = "";
				String releaseName = "";
				String CycleName = "";
				NodeList nList = doc.getElementsByTagName("Variable");

				for (int temp = 0; temp < nList.getLength(); temp++) {

					Node nNode = nList.item(temp);
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {
						Element eElement = (Element) nNode;
						String Envname = eElement.getElementsByTagName("Name").item(0).getTextContent();

						if (Envname.contains("DeviceName")) {
							DeviceName = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("DeviceIP")) {
							DeviceIP = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("DevicePort")) {
							DevicePort = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("DeviceVersion")) {
							DeviceVersion = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("DevicePlatForm")) {
							DevicePlatForm = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("DeviceID")) {
							DeviceID = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("DeviceUDID")) {
							DeviceUDID = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("App_Package")) {
							App_Package = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						if (Envname.contains("App_Activity")) {
							App_Activity = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("Sys_Port")) {
							Sys_Port = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("WDA_Port")) {
							WDA_Port = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("Bundle_ID")) {
							Bundle_ID = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("Sauce_Username")) {
							Sauce_Username = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("Accesskey")) {
							Accesskey = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("Apppath")) {
							Apppath = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("Orienation")) {
							Orienation = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("AppiumVersion")) {
							Appiumversion = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("Datacenter")) {
							Datacenter = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("Cloudtype")) {
							Cloudtype = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("TestApi")) {
							TestApi = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("Devicelocation")) {
							Devicelocation = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("app_name")) {
							app_name = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("ProductID")) {
							ProductID = eElement.getElementsByTagName("Value").item(0).getTextContent();
						}

						else if (Envname.contains("ClientID")) {
							ClientID = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("ExecutionRequestId")) {
							Pub_ExecutionRequestId = Integer
									.parseInt(eElement.getElementsByTagName("Value").item(0).getTextContent());

						} else if (Envname.contains("Env_ResultPath")) {
							resultpath = eElement.getElementsByTagName("Value").item(0).getTextContent();
							baseResultPath = resultpath.replace("\\", "\\\\");

						} else if (Envname.contains("Env_ReleaseName")) {
							releaseName = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("Env_CycleName")) {
							CycleName = eElement.getElementsByTagName("Value").item(0).getTextContent();
							ResultCyclepath = baseResultPath + "\\\\" + releaseName + "\\\\" + CycleName;

						} else if (Envname.contains("Env_ReleaseID")) {
							pub_ReleaseId = Integer
									.parseInt(eElement.getElementsByTagName("Value").item(0).getTextContent());

						} else if (Envname.contains("Env_CycleID")) {
							pub_CycleId = Integer
									.parseInt(eElement.getElementsByTagName("Value").item(0).getTextContent());

						}  else if (Envname.contains("ExecuteUser")) {

							int getuser = Integer
									.parseInt(eElement.getElementsByTagName("Value").item(0).getTextContent());
							Cur_UserID = getuser;
							pub_UserID = getuser;

						} else if (Envname.contains("AppEnvironment")) {
							String nameurl = "";
							nameurl = eElement.getElementsByTagName("Value").item(0).getTextContent();							
							navigateBrowseURL(nameurl);

						} else if (Envname.contains("TestSetId")) {
							pub_testsets = Integer
									.parseInt(eElement.getElementsByTagName("Value").item(0).getTextContent());
							loadtestsetname(releaseName, CycleName);

						} else if (Envname.contains("Current_Browser")) {
							String getTest = eElement.getElementsByTagName("Value").item(0).getTextContent();

						}
						else if (Envname.contains("Current_Testcase")) {
							String getTest = eElement.getElementsByTagName("Value").item(0).getTextContent();
							String Testcasecount = getTest;

						} else if (Envname.contains("Env_IterationSelected")) {
							String getItera = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("ExistWaitTime")) {
							pub_EnvValue = Integer
									.parseInt(eElement.getElementsByTagName("Value").item(0).getTextContent());

						} else if (Envname.contains("TDEnvID")) {
							pub_TDEnvID = eElement.getElementsByTagName("Value").item(0).getTextContent();

						} else if (Envname.contains("BuildNo")) {
							pub_BuildNo = eElement.getElementsByTagName("Value").item(0).getTextContent().trim()
									.replaceAll("\n ", "");

						} else if (Envname.contains("Env_CycleID")) {
							pub_TestcaseWaitTime = Integer
									.parseInt(eElement.getElementsByTagName("Value").item(0).getTextContent());
						}else if (Envname.contains("Env_ScreenShotFlag")) {
							Env_ScreenShotFlag = Integer
									.parseInt(eElement.getElementsByTagName("Value").item(0).getTextContent());
						}								
					}
				}
				process_currentExecution();
				loadTestStepDesc();
				loadTestcaseObjectEnaDisable();

				/** Integrated test **/
				load_integratedsub_Module();
			}
		} catch (Exception e) {
			Loggerupdator("Framework Initialization Failed..!","Initialization",0,e.toString());
			e.printStackTrace();
		}
	}

	private void process_currentExecution() {

		try{
			
			String strQuery = "Delete from tbl_CurrentExecution where TestcaseID=" + Integer.parseInt(pubTestCaseID)
			+ " and userid=" + pub_UserID + " and cycleID=" + pub_CycleId + "";
	        RestApicall(strQuery); // Api Call
	
	        /****************************************************************************************************/	        
			strQuery = "Insert into tbl_CurrentExecution (TestcaseID,UserID,Status,cycleid) values ("
					+ Integer.parseInt(pubTestCaseID) + "," + pub_UserID + ",'Started'," + pub_CycleId + ")";
			RestApicall(strQuery); // Api Call
			
		}catch(Exception ex){
			Loggerupdator("process_currentExecution Failed..!","process_currentExecution",0,ex.toString());

		}
	}

	private void load_integratedsub_Module() {
		
		try{		
			String qry = " select a.IntegID,a.TestcaseFlag,b.IntegGroupName,c.PriorityStatus from tbl_Testcase a ";
			qry += " inner join tbl_IntegrationTestcase b on b.IntegID = a.IntegID  inner join tbl_PriorityStatus c on c.PID = a.TestcaseFlag  where a.TestcaseID = "
					+ Integer.parseInt(pubTestCaseID) + " and a.IntegratedFlag = 1";

			JSONArray jsondata = RestApicall(qry); // Api Call			
			if (jsondata.length() > 0) {
				JSONObject rs2 = jsondata.getJSONObject(0);
				pub_IsIntegrationTC = 1;
				pub_IntegrationID = rs2.getInt("IntegID");
				pub_IntegrationGrpName = rs2.getString("IntegGroupName");
				pub_SubModuleID = rs2.getInt("TestcaseFlag");
				pub_SubModuleName = rs2.getString("PriorityStatus");
			}
		}catch(Exception ex){
			Loggerupdator("process_currentExecution Failed..!","load_integratedsub_Module",0,ex.toString());
			System.out.println(ex);
		}	
	}
	private void loadtestsetname(String releaseName, String cycleName) {
	
		String qry = "SELECT Testsetname FROM tbl_testset WHERE testsetid = " + pub_testsets + "";
		try{		
			String TestSetName = "";
			JSONArray jsondata= RestApicall(qry);						
			if (jsondata.length() > 0) {
				JSONObject rs2 = jsondata.getJSONObject(0);	
				TestSetName = rs2.getString("Testsetname");	
			}
			ResultCyclepath = baseResultPath + "\\\\" + releaseName + "\\\\" + cycleName + "\\\\"
					+ TestSetName;		
		}catch(Exception ex){
		Loggerupdator("Failed to loadtestsetname..Query: "+qry,"loadtestsetname",0,ex.toString());
		 System.out.println(ex);
		}
		
	}

	public void navigateBrowseURL(String nameurl) {
		
		String qry = "SELECT Id,PortalURL,EnvironmentName FROM tbl_EnvironmentDetails WHERE EnvironmentName ='"
				+ nameurl + "'";
		try {

			JSONArray jsondata = RestApicall(qry);
			if (jsondata.length() > 0) {
				JSONObject rs = jsondata.getJSONObject(0);
				Pub_BrowserName = rs.getString("PortalURL");
				pub_EnvName = rs.getString("EnvironmentName");
				pub_Env_ID = String.valueOf(rs.getInt("Id"));
			}
		} catch (Exception e) {
			Loggerupdator("Failed to navigateBrowseURL Query: " + qry, "loadtestsetname", 0, e.toString());
			System.out.println(e);
		}
	}

	// Navigate Url to Selected Browser
	public void loadURL(String Pub_BrowserName) {
			
		try {	
			if (!Pub_DefaultBrowserName.equalsIgnoreCase("Winapp")) {

				if (Pub_DefaultBrowserName.equalsIgnoreCase("Terminal")) {
				
					Desktop desktop = Desktop.getDesktop();
					desktop.open(new File(Pub_BrowserName));
					
					String fileName = Pub_BrowserName.toString();
				    int index = fileName.lastIndexOf('.');
				    if(index > 0) {
				    	Terminaltype = fileName.substring(index + 1);
				    }		
					Loggerupdator("Open Terminal" + Pub_BrowserName, "loadURL", 1, "");

					// Launch AS400 Application

				} else if (Pub_DefaultBrowserName.equals("IOS")) {

					DesiredCapabilities dc = new DesiredCapabilities();
					
					try {
						if (Cloudtype.contains("Sauce Labs")) {
							Appuploadsauce();
							String AppName = "sauce-storage:" + app_name + ".ipa";
							dc.setCapability("deviceName", DeviceName);
							dc.setCapability("platformName", DevicePlatForm);
							dc.setCapability("platformVersion", DeviceVersion);
							dc.setCapability("wdaLocalPort", WDA_Port);
							dc.setCapability("appiumVersion", Appiumversion);
							dc.setCapability("deviceOrientation", Orienation);
							dc.setCapability("app", AppName);

							if (Datacenter.equalsIgnoreCase("US West 1")) {

								IOSdriver = new IOSDriver<>(new URL("https://" + Sauce_Username + ":" + Accesskey
										+ "@ondemand.us-west-1.saucelabs.com:443/wd/hub"), dc);

								Loggerupdator("**Sauce Labs US West 1 SERVER Connected  : ", "loadURL", 2, "");

							} else if (Datacenter.equalsIgnoreCase("EU Central 1")) {

								IOSdriver = new IOSDriver<>(new URL("https://" + Sauce_Username + ":" + Accesskey
										+ "@ondemand.eu-central-1.saucelabs.com:443/wd/hub"), dc);

								Loggerupdator("**Sauce Labs EU Central 1 SERVER Connected  : ", "loadURL", 2, "");

							} else if (Datacenter.equalsIgnoreCase("Headless US-East")) {

								IOSdriver = new IOSDriver<>(new URL("https://" + Sauce_Username + ":" + Accesskey
										+ "@ondemand.us-west-1.saucelabs.com:443/wd/hub"), dc);
								Loggerupdator("**Sauce Labs Headless US-East SERVER Connected  : ", "loadURL", 2, "");

							}
						} else if (Cloudtype.equalsIgnoreCase("Test Object")) {

							dc.setCapability("deviceName", DeviceName);
							dc.setCapability("platformName", DevicePlatForm);
							dc.setCapability("platformVersion", DeviceVersion);
							dc.setCapability("wdaLocalPort", WDA_Port);
							dc.setCapability("appiumVersion", Appiumversion);
							dc.setCapability("deviceOrientation", Orienation);
							dc.setCapability("testobject_api_key", TestApi);

							if (Devicelocation.equalsIgnoreCase("Europe")) {

								IOSdriver = new IOSDriver<>(new URL("https://appium.testobject.com/wd/hub"), dc);

								Loggerupdator("**Test Object SERVER Connected  : ", "loadURL", 2, "");

							} else if (Devicelocation.equalsIgnoreCase("United_states")) {

								IOSdriver = new IOSDriver<>(new URL("https://us1-manual.app.testobject.com/wd/hub"),
										dc);
								Loggerupdator("**Test Object SERVER Connected  : ", "loadURL", 2, "");
							}

						} else if (Cloudtype.equalsIgnoreCase("None")) {

							dc.setCapability(MobileCapabilityType.UDID, DeviceUDID);
							dc.setCapability("deviceName", DeviceName);
							dc.setCapability("platformName", DevicePlatForm);
							dc.setCapability("platformVersion", DeviceVersion);
							dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, Bundle_ID);
							dc.setCapability("wdaLocalPort", WDA_Port);
							IOSdriver = new IOSDriver<>(new URL("http://" + DeviceIP + ":" + DevicePort + "/wd/hub"),
									dc);
							Loggerupdator("**IOSdriver Connected  : ", "loadURL", 2, "");

						}
					} catch (Exception e) {
						Loggerupdator("Could not get iOS Driver connection", "loadURL", 0, e.toString());
						update_device_status(0, DeviceID);
						Thread.sleep(5000);
						System.exit(0);
					}

				} else if (Pub_DefaultBrowserName.equals("Android")) {

					DesiredCapabilities dc = new DesiredCapabilities();
					try {

						if (Cloudtype.contains("Sauce Labs")) {
							if (Appuploadsauce()) {
								String AppName = "sauce-storage:" + app_name + ".apk";
								dc.setCapability("platformName", "Android");
								dc.setCapability("deviceOrientation", Orienation);
								dc.setCapability("app", AppName);
								dc.setCapability("platformVersion", DeviceVersion);
								dc.setCapability("deviceName", DeviceName);
								dc.setCapability("appiumVersion", Appiumversion);
								dc.setCapability("systemPort", Sys_Port);
								Loggerupdator("Connecting to the Sauce Server... ","openTestNG",1,"");
								if (Datacenter.equalsIgnoreCase("US West 1")) {

									AndroidDriver = new AndroidDriver<>(new URL("https://" + Sauce_Username + ":" + Accesskey
											+ "@ondemand.us-west-1.saucelabs.com:443/wd/hub"), dc);

									Loggerupdator("**Sauce Labs US West 1 SERVER Connected  : ","loadURL" ,2,"");

								} else if (Datacenter.equalsIgnoreCase("EU Central 1")) {

									AndroidDriver = new AndroidDriver<>(new URL("https://" + Sauce_Username + ":" + Accesskey
											+ "@ondemand.eu-central-1.saucelabs.com:443/wd/hub"), dc);

									Loggerupdator("**Sauce Labs EU Central 1 SERVER Connected  : ","loadURL" ,2,"");
								
								} else if (Datacenter.equalsIgnoreCase("Headless US-East")) {

									AndroidDriver = new AndroidDriver<>(new URL("https://" + Sauce_Username + ":" + Accesskey
											+ "@ondemand.us-west-1.saucelabs.com:443/wd/hub"), dc);
									Loggerupdator("**Sauce Labs Headless US-East SERVER Connected  : ","loadURL" ,2,"");

								}
							}
						} else if (Cloudtype.equalsIgnoreCase("Test Object")) {

							dc.setCapability("platformName", "Android");
							dc.setCapability("deviceOrientation", Orienation);
							dc.setCapability("testobject_api_key", TestApi);
							dc.setCapability("platformVersion", DeviceVersion);
							dc.setCapability("deviceName", DeviceName);
							dc.setCapability("appiumVersion", Appiumversion);
							dc.setCapability("systemPort", Sys_Port);
							Loggerupdator("Connecting to the Sauce Server... ","openTestNG",1,"");		
							if (Devicelocation.equalsIgnoreCase("Europe")) {

								AndroidDriver = new AndroidDriver<>(new URL("https://appium.testobject.com/wd/hub"), dc);

								Loggerupdator("**Test Object SERVER Connected  : ","loadURL" ,2,"");

							} else if (Devicelocation.equalsIgnoreCase("United_states")) {

								AndroidDriver = new AndroidDriver<>(new URL("https://us1-manual.app.testobject.com/wd/hub"), dc);
								Loggerupdator("**Test Object SERVER Connected  : ","loadURL" ,2,"");

							}
						} else if (Cloudtype.equalsIgnoreCase("None")) {

							dc.setCapability("platformVersion", DeviceVersion);
							dc.setCapability(MobileCapabilityType.UDID, DeviceUDID);
							dc.setCapability("platformName", DevicePlatForm);
							dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
							dc.setCapability(MobileCapabilityType.DEVICE_NAME, DeviceName);
							dc.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, App_Package);
							dc.setCapability(AndroidMobileCapabilityType.SYSTEM_PORT, Sys_Port);
							dc.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, App_Activity);
							AndroidDriver = new AndroidDriver<>(new URL("http://" + DeviceIP + ":" + DevicePort + "/wd/hub"), dc);
							Loggerupdator("**Android Driver Connected  : ","loadURL" ,2,"");
						}
					} catch (Exception e) {
						Loggerupdator("Could not get Android Driver connection","loadURL" ,0,e.toString());
						update_device_status(0, DeviceID);
						Thread.sleep(5000);
						System.exit(0);
					}
									
				} else {
					driver.manage().window().maximize();
					Loggerupdator("Browser Navigate to " + Pub_BrowserName, "loadURL", 1, "");
					driver.get(Pub_BrowserName);
					for (String winHandle : driver.getWindowHandles()) {
						parentHandle = winHandle;
					}
				}
			}			
		} catch (Exception ex) {
			Loggerupdator("could not navigate to " + Pub_BrowserName, "loadURL", 0, ex.toString());
			updateFailstatus();
		}
	}

	public void updateFailstatus() {

		String strQuery="";
		try {
			 strQuery = "Update tbl_CurrentExecution set Status='Failed' where TestcaseID="
					+ Integer.parseInt(pubTestCaseID) + " and UserID=" + pub_UserID + " and cycleID = " + pub_CycleId
					+ "";
			RestApicall(strQuery);
			driver.close();
			driver.quit();
			driver = null;
			System.exit(0);
		} catch (Exception ex) {
			Loggerupdator("Failed to update the Failstatus ","updateFailstatus",0,ex.toString());
			System.exit(0);
		}
	}

	// Get Description for Test steps
	public void loadTestStepDesc() {
		
		String qryGetTestData="";
		try {
			
			 qryGetTestData = "SELECT * FROM tbl_TestStepDescription WHERE testcaseid = "
					+ Integer.parseInt(pubTestCaseID) + "";
			JSONArray rs1 = RestApicall(qryGetTestData);
			if (rs1.length() > 0) {
				TestStepDesc = new HashMap<String, String>();
				for (int i = 0; i <= rs1.length() - 1; i++) {
					JSONObject rs = rs1.getJSONObject(i);
					String strObjectMap = rs.getInt("ObjectID") + "_" + rs.getInt("SubIteration");
					String strTestStepDesc = rs.getString("TestStep_Desc");
					if (strTestStepDesc == null || strTestStepDesc == "" || strTestStepDesc == "null") {
						TestStepDesc.put(strObjectMap, "");
					} else {
						TestStepDesc.put(strObjectMap, strTestStepDesc);
					}
				}
			}

		} catch (Exception e) {
			Loggerupdator("Failed to load loadTestStepDesc Query: "+qryGetTestData,"loadTestStepDesc",0,e.toString());
			System.out.println("Error: " + e);
		}
	}

	// Load Testdata for current testcase and iteration
	public void loadTestData() {

		String qryGetTestData ="";
		try {

			pub_Cur_Iteration = ArrIterations[IterationCount].toString();
			log.info("*******************************************************************");
			log.info("Iteration " + pub_Cur_Iteration + " Started");
			log.info("*******************************************************************");
			if (BrowserRequired.contains("Y") && IterationCount != 0) {

				log.info("Navigate Url For Every Iteration");
				loadURL(Pub_BrowserName);
			}
			tcStatus = "Pass";
			pub_getIterationStatus = "Passed";

			// Get Test Data Values
			/************************************************************************************/
			 qryGetTestData = "SELECT * FROM tbl_IterationMapping WHERE testcaseid = "
					+ Integer.parseInt(pubTestCaseID)
					+ " AND iterationid = (SELECT IterationId FROM tbl_Iteration WHERE TestcaseID= "
					+ Integer.parseInt(pubTestCaseID) + " AND IterationNumber= " + Integer.parseInt(pub_Cur_Iteration)
					+ " AND TDEnvID = " + Integer.parseInt(pub_TDEnvID) + "  AND ProductNameID = "
					+ Integer.parseInt(ProductID) + " AND RiderCodeNameID = 0 )";
			
			JSONArray jsondata= RestApicall(qryGetTestData);
			map = new HashMap<String, String>();
			for (int i = 0; i <= jsondata.length() - 1; i++) {
				
				JSONObject rs = jsondata.getJSONObject(i);
				int objId = rs.getInt("objID");
				int subId = rs.getInt("SubIterationID");
				String strObjectMap = objId + "_" + subId;
				
				String strTestData = rs.getString("InputData");

				if (strTestData == null || strTestData == "") {
					map.put(strObjectMap, "");
				} else {
					map.put(strObjectMap, strTestData);
				}		
			}		
			if (callfolderOnce == 1) {
				callfolderOnce = 0;
				createResultFolder();
			}
			IterationCount = IterationCount + 1;
		} catch (Exception e) {
			Loggerupdator("Failed to load loadTestData Query: "+qryGetTestData,"loadTestData",0,e.toString());	
		}
	}
	public void isAlertPresent() {
		try {

			Thread.sleep(2000);
			Alert alert = driver.switchTo().alert();
			System.out.println(alert.getText());
			ActualTestDataValue = alert.getText();
			sno++;
			tsStatus = "Pass";
			result("Alert_Message", "", "Done", "0", 0, "Click");
			alert.accept();
			log.info("Alert is performed");
			// return true;
		} catch (Throwable e) {
			System.err.println("Alert isn't present!!");
			// log.info("Alert is not performed" );
			// return false;
		}
	}
	
	//GetTestData based by flow condition
	
	public String fnGetTestData(String strObjectID, String strSubIterationID) {
		String strReturn = "";
		try {
			if (_ItsSubFlowTC == 1) {

				strReturn = _subFlowTestData.get(strObjectID + "_" + String.valueOf(strSubIterationID));

			} else if (_ItsRiderFlowTC == 1) {

				strReturn = _Ridertestdata.get(strObjectID + "_" + String.valueOf(strSubIterationID));

			} else {
				strReturn = map.get(strObjectID + "_" + String.valueOf(strSubIterationID));
			}
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return strReturn;
	}

	public void Web_automation(String Screen_ID, String objectName, String ObjectClass, String eventType,
			String Cur_objectId, int subIteration, String KeywordName, String str_Property) {

		try {

			if (tcStatus != "Fail") {
				waitForJStoLoad();
			    WaitUntilElementPresent(objectName,str_Property,Pub_DefaultBrowserName);
			    Pub_dynamicValue = "";
				ActualTestDataValue = "";
				Dynamic_TestValue="";
				String CurrenWindowName = "";
				String str_NoData = "";
				tsStatus = "Done";
				for (String winHandle : driver.getWindowHandles()) {
					Window_count = 1;
					CurrenWindowName = winHandle;
				}
				driver.switchTo().window(CurrenWindowName);		 	
				String testData = "";
				
				if (sno == 0) {
					writeIterationHTML("");
				}
				if (ObjectClass == "DYNAMIC") {
					WebElement element = null;
					if (str_Property.equalsIgnoreCase("ID")) {
						element = driver.findElement(By.id(objectName));
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						element = driver.findElement(By.xpath(objectName));
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						element = driver.findElement(By.name(objectName));
					}

					if (eventType == "SETTEXT" || eventType == "CLICK") {
						String Dyn_Data = element.getAttribute("value");
						log.info("Before Dyn");
						Func_UpdateDynamicValue(KeywordName, Dyn_Data);
						testData = Dyn_Data;
					} else {
						String Dyn_Data = element.getText();
						Func_UpdateDynamicValue(KeywordName, Dyn_Data);
						testData = Dyn_Data;
					}
				} else if (eventType == "CLICK") {
					if (str_Property.equalsIgnoreCase("ID")) {

						WebElement element = driver.findElement(By.id(objectName));
						if (element.isDisplayed()) {
							element.click();
						}
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						WebElement element = driver.findElement(By.name(objectName));
						if (element.isDisplayed()) {
							element.click();
						}
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						WebElement element = driver.findElement(By.xpath(objectName));
						if (element.isDisplayed()) {
							element.click();
						}
					}

					else if (str_Property.equalsIgnoreCase("CSS")) {
						log.info("TEST CSS   " + objectName);
						WebElement element = driver.findElement(By.cssSelector(objectName));
						if (element.isDisplayed()) {
							element.click();
						}
					} else if (str_Property == "LINK") {
						List<WebElement> linkElements = driver.findElements(By.tagName("a"));
						String[] linkTexts = new String[linkElements.size()];
						int i = 0;

						// extract the link texts of each link element
						for (WebElement e : linkElements) {
							linkTexts[i] = e.getText();
							i++;
							if (e.getText().contains(objectName)) {
								WebElement element = driver.findElement(By.linkText(e.getText()));
								element.click();
								break;
							}
						}
					} else if (str_Property == "P_LINK") {
						List<WebElement> linkElements = driver.findElements(By.tagName("a"));
						String[] linkTexts = new String[linkElements.size()];
						int i = 0;

						// extract the link texts of each link element
						for (WebElement e : linkElements) {
							linkTexts[i] = e.getText();
							i++;
							if (e.getText().contains(objectName)) {
								WebElement element = driver.findElement(By.partialLinkText(e.getText()));
								element.click();
								break;
							}
						}

					} else if (str_Property == "BUTTON") {
						List<WebElement> linkElements = driver.findElements(By.tagName("button"));
						String[] linkTexts = new String[linkElements.size()];
						int i = 0;

						for (WebElement e : linkElements) {
							linkTexts[i] = e.getText();
							i++;
							if (e.getText().contains("Go to summary & payment")) {
								System.out.println("PaRTIAl LINK  1234567890     " + e.getText());
								WebElement element = driver.findElement(By.partialLinkText(e.getText()));
								element.click();
								break;
							}
						}
					} else if (str_Property == "DYNAMIC") {
						WebElement element = driver.findElement(By.xpath(objectName));

						String Dyn_Data = element.getAttribute("value");
						Func_UpdateDynamicValue(KeywordName, Dyn_Data);
					} else if (str_Property == "DYNAMIC_1") {
						WebElement element = driver.findElement(By.id(objectName));
						String Dyn_Data = element.getAttribute("value");
						Func_UpdateDynamicValue(KeywordName, Dyn_Data);
					}

					else if (str_Property == "TABLE") {
						WebElement parentTable = driver.findElement(By.xpath(objectName + "/tbody"));
						List<WebElement> rows = parentTable.findElements(By.xpath("./tr"));
						int row_Count = rows.size();
						if (row_Count > 0) {
							String TableValue = driver
									.findElement(By.xpath("html/body/section/div[3]/div/div/table/tbody/tr[1]/td[3]"))
									.getText();

							String Package_Value = driver
									.findElement(By.xpath("html/body/section/div[3]/div/div/div[1]/div[2]")).getText();

							driver.findElement(
									By.xpath("html/body/section/div[3]/div/div/table/tbody/tr[1]/td[7]/a[1]")).click();

						} else {
							checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "");
						}
					}
					Thread.sleep(300);

				} else if (eventType == "DATE") {
					
					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (str_Property.equalsIgnoreCase("ID")) {
						WebElement element = driver.findElement(By.id(objectName));
						element.click();
						SelectDayFromMultiDateCalendar(Cur_TestData);
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						WebElement element = driver.findElement(By.name(objectName));
						element.click();
						SelectDayFromMultiDateCalendar(Cur_TestData);
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						WebElement element = driver.findElement(By.xpath(objectName));
						element.click();
						SelectDayFromMultiDateCalendar(Cur_TestData);
					}
				} else if (eventType == "SETTEXT") {

					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (String.valueOf(Cur_TestData).toUpperCase().equalsIgnoreCase("NODATA")) {
						Cur_TestData = "";
					} else if (Cur_TestData.toUpperCase().startsWith("DYN_")) {
						log.info("Before Dyn2");
						Get_DynamicValue(Cur_TestData);
						log.info("Dynamic Value1" + Dynamic_TestValue);
						Cur_TestData = Dynamic_TestValue;
					} else if (Cur_TestData.toUpperCase().startsWith("ENV_")) {
						Get_EnvironmentValue(Cur_TestData);
						Cur_TestData = Dynamic_TestValue;
					}

					if (str_Property.equalsIgnoreCase("ID")) {
						WebElement element = driver.findElement(By.id(objectName));
						element.clear();
						element.sendKeys(Cur_TestData);
						testData = Cur_TestData;
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						WebElement element = driver.findElement(By.name(objectName));
						element.clear();
						element.sendKeys(Cur_TestData);
						testData = Cur_TestData;
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						WebElement element = driver.findElement(By.xpath(objectName));

						element.clear();
						element.sendKeys(Cur_TestData);
						testData = Cur_TestData;
					} else if (Screen_ID == "Second") {
						List<WebElement> myElements = driver.findElements(By.id(objectName));

						myElements.get(1).sendKeys(Cur_TestData);
						testData = Cur_TestData;
					}

					else if (str_Property == "TABLE") {
						String[] TableValues = Cur_TestData.split(",");

						int Start_Row = Integer.parseInt(TableValues[0]);
						int ColumnIDX = Integer.parseInt(TableValues[1]);
						selectTableFirstRow(objectName, Start_Row, ColumnIDX);
						testData = "";
					} else if (str_Property == "TABLE_1") {
						String[] TableValues = Cur_TestData.split(",");

						int Start_Row = Integer.parseInt(TableValues[0]);
						int ColumnIDX = Integer.parseInt(TableValues[1]);
						Table_UnselectCheckbox(objectName, Start_Row, ColumnIDX);
						testData = "";
					} else if (str_Property == "TABLE_2") {
						String[] TableValues = Cur_TestData.split(",");

						int Start_Row = Integer.parseInt(TableValues[0]);
						int ColumnIDX = Integer.parseInt(TableValues[1]);
						String Dynamic_object = TableValues[2];
						int Dynamic_ObjectIDX = Integer.parseInt(TableValues[3]);
						String Dynamic_ObjectType = TableValues[4];
						Table_SelectRadio_dynamicNo(objectName, Start_Row, ColumnIDX, Dynamic_object, Dynamic_ObjectIDX,
								Dynamic_ObjectType);
						testData = "";
					}

				} else if (eventType == "SELECT") {
					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (String.valueOf(Cur_TestData) == "null") {
						Cur_TestData = "";
					} else {
						if (Cur_TestData.toUpperCase().startsWith("DYN_")) {
							Get_DynamicValue(Cur_TestData);
							Cur_TestData = Dynamic_TestValue;
						}
					}
					if (str_Property.equalsIgnoreCase("ID")) {
						Select oSelect = new Select(driver.findElement(By.id(objectName)));

						oSelect.selectByVisibleText(Cur_TestData);
						testData = Cur_TestData;
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						WebElement element = driver.findElement(By.name(objectName));
						Select se = new Select(element);
						se.selectByVisibleText(Cur_TestData);
						testData = Cur_TestData;
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						WebElement element = driver.findElement(By.xpath(objectName));
						Select se = new Select(element);
						se.selectByVisibleText(Cur_TestData);
						testData = Cur_TestData;
					}
				} else if (eventType == "VERIFY") {
					String result = "";
					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));

					if (Cur_TestData.startsWith("DYN")) {

						Get_DynamicValue(Cur_TestData);
						Cur_TestData = Pub_dynamicValue;

					}
					if (String.valueOf(Cur_TestData) == "null") {
						Cur_TestData = "";
					}
					KeywordName = "Verify_" + KeywordName;
					if (str_Property.equalsIgnoreCase("ID")) {
						WebElement element = driver.findElement(By.id(objectName));
						result = element.getText();
						JavascriptExecutor js = (JavascriptExecutor) driver;
						js.executeScript(
								"arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
								element);
						testData = Cur_TestData;
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						WebElement element = driver.findElement(By.name(objectName));
						result = element.getText();
						JavascriptExecutor js = (JavascriptExecutor) driver;
						js.executeScript(
								"arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
								element);
						testData = Cur_TestData;
					}

					else if (str_Property.equalsIgnoreCase("XPATH")) {
						WebElement element = driver.findElement(By.xpath(objectName));
						result = element.getText();
						JavascriptExecutor js = (JavascriptExecutor) driver;
						js.executeScript(
								"arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
								element);
						testData = Cur_TestData;
					} else if (str_Property == "VERIFY_1") {
						WebElement element = driver.findElement(By.name(objectName));
						result = element.getAttribute("value");
						JavascriptExecutor js = (JavascriptExecutor) driver;
						js.executeScript(
								"arguments[0].setAttribute('style', 'background: grey; border: 2px solid red;');",
								element);
						// driver.executeScript("arguments[0].style.backgroundColor='grey'",element);
						testData = Cur_TestData;
					} else if (str_Property == "VERIFY_IMAGE") {
						WebElement element = driver.findElement(By.xpath(objectName));
						// result=element.getAttribute("src");

						result = ((JavascriptExecutor) driver)
								.executeScript("return arguments[0].attributes['src'].value;", element).toString();

						if (result.indexOf("/") != -1) {
							result = result.split("/")[2];
						}
						JavascriptExecutor js = (JavascriptExecutor) driver;
						js.executeScript(
								"arguments[0].setAttribute('style', 'background: grey; border: 2px solid red;');",
								element);
						// driver.executeScript("arguments[0].style.backgroundColor='grey'",element);
						testData = Cur_TestData;
					}

					ActualTestDataValue = result;
					// System.out.println("VERiFY DATA " + ActualTestDataValue +
					// " " + testData);
					if (ActualTestDataValue.trim().equals(testData.trim())) {
						tsStatus = "Pass";
					} else {
						pub_getTestcaseStatus = "Failed";
						pub_getIterationStatus = "Failed";
						tsStatus = "Fail";
						TestcaseFinalStatus = "Fail";
						tcStatus = "Fail";
						// checkErrorTest(Cur_objectId,subIteration,eventType,KeywordName);
					}

				} else if (eventType == "FOCUS") {
					JavascriptExecutor jse = (JavascriptExecutor) driver;

					if (str_Property.equalsIgnoreCase("ID")) {
						jse.executeScript("driver.findElement(By.id(" + objectName + "));");
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						jse.executeScript("driver.findElement(By.name(" + objectName + "));");
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						jse.executeScript("driver.findElement(By.xpath(" + objectName + "));");
					}
				} else if (eventType == "GETPROPVALUE") {
					String result = "";
					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					String[] parts = Cur_TestData.split(";");
					String part1 = parts[0];
					String part2 = parts[1];
					if (str_Property.equalsIgnoreCase("ID")) {
						WebElement element = driver.findElement(By.id(objectName));
						result = element.getAttribute(part1);
						testData = part2;
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						WebElement element = driver.findElement(By.name(objectName));
						result = element.getAttribute(part1);
						testData = part2;
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						WebElement element = driver.findElement(By.xpath(objectName));
						result = element.getAttribute(part1);
						testData = part2;
					}
					ActualTestDataValue = result;
					if (result.equals(testData)) {
						tsStatus = "Pass";
					} else {
						tsStatus = "Fail";
						checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "");
					}
				} else if (eventType == "EXIST") {
					SetWaitTime(5);
					if (str_Property.equalsIgnoreCase("ID")) {
						if (driver.findElements(By.id(objectName)).size() != 0) {
							System.out.println("Element is Present");
							tsStatus = "Pass";
						} else {
							System.out.println("Element is Absent");
							checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "");
						}
					} else if (str_Property.equalsIgnoreCase("NAME")) {
						WebElement element = driver.findElement(By.xpath(objectName));
						if (driver.findElements(By.name(objectName)).size() != 0) {
							System.out.println("Element is Present");
							tsStatus = "Pass";
						} else {
							checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "");
						}
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						WebElement element = driver.findElement(By.xpath(objectName));
						if (driver.findElements(By.xpath(objectName)).size() != 0) {
							tsStatus = "Pass";
						} else {
							checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "");
						}
					}
				}

				else if (eventType == "GCHECK") {
					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					System.out.println("IN TESTDATA  " + Cur_TestData);
					if (String.valueOf(Cur_TestData) == "null") {
						Cur_TestData = "";
					}
					if (str_Property.equalsIgnoreCase("ID")) {
					} else if (str_Property.equalsIgnoreCase("NAME")) {
					} else if (str_Property.equalsIgnoreCase("XPATH")) {
						WebElement WebElement1 = driver.findElement(By.xpath(objectName));
						List<WebElement> AllCheckBoxes = WebElement1.findElements(By.xpath("//p/label"));

						int RowCount = WebElement1.findElements(By.xpath("//p/label")).size();
						String[] array = Cur_TestData.split(",", -1);
						String Str_String = Cur_TestData.trim().replaceAll(" ,", ",").replaceAll(", ", ",");
						for (WebElement AllCheck : AllCheckBoxes) {
							// Check the check boxes based on index

							String dddd = AllCheck.getText();

							if (("," + Str_String + ",").contains("," + dddd + ",")) {
								Thread.sleep(4000);
								String dddd11 = generateXPATH(AllCheck, "");
								WebElement termsElement = driver.findElement(By.xpath(dddd11));
								Thread.sleep(2000);
								termsElement.click();
							}

						}

						testData = Cur_TestData;
					}
				} else if (eventType == "MANUAL") {
					pub_getTestcaseStatus = "Semi-Auto";
					pub_getIterationStatus = "Semi-Automated";
					tsStatus = "Semi-Automated";
					TestcaseFinalStatus = "Semi-Automated";
					testData = "";
					KeywordName = "Manual Step";

				}
				sno++;
				result(KeywordName, testData, tsStatus, Cur_objectId, subIteration, eventType);
				if (eventType == "SETTEXT") {
					Loggerupdator("Keyword Performed  :" + KeywordName + "\n Test Data :" + testData + "\n Status: "
							+ tsStatus + "\n Event Type: " + eventType + "\n Property: " + str_Property + "\n Object: "
							+ objectName, "Web_Automation", 1, "");
				} else {
					Loggerupdator(
							"Keyword Performed  :" + KeywordName + "\n Status: " + tsStatus + "\n Event Type: "
									+ eventType + "\n Property: " + str_Property + "\n Object: " + objectName,
							"Web_Automation", 1, "");
				}
			}

		} catch (Exception ex) {

			Loggerupdator("Keyword " + KeywordName + " is not performed", "Web_Automation", 0, ex.toString());
			checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, ex.toString());

		}
	}
	
	public void Android_automation(String Screen_ID, String objectName, String ObjectClass, String eventType,
			String Cur_objectId, int subIteration, String KeywordName, String str_Property) {

		try {

			if (tcStatus != "Fail") {
				if (sno == 0) {
					writeIterationHTML("");
				}
				Pub_dynamicValue = "";
				ActualTestDataValue = "";
				Dynamic_TestValue="";
				String testData = "";
				tsStatus = "Done";
				AndroidElement element = null;
				if (eventType == "CLICK") {
					if (ObjectClass.equalsIgnoreCase("selclick")) {
						if (str_Property == "ID") {
							AndroidDriver.findElement(By.id(objectName)).click();
							tsStatus = "Done";
						} else if (str_Property == "NAME") {
							AndroidDriver.findElement(By.name(objectName)).click();
							tsStatus = "Done";
						} else if (str_Property == "XPATH") {
							AndroidDriver.findElement(By.xpath(objectName)).click();
							tsStatus = "Done";
						}
					} else if (str_Property == "CONTEXT") {
						((ContextAware) AndroidDriver).context(objectName);
						tsStatus = "Done";
					}
				} else if (eventType == "ENTER") {
					if (str_Property == "ID") {
						AndroidDriver.findElement(By.id(objectName)).sendKeys(Keys.ENTER);
						tsStatus = "Done";
					} else if (str_Property == "NAME") {
						AndroidDriver.findElement(By.name(objectName)).sendKeys(Keys.ENTER);
						tsStatus = "Done";
					} else if (str_Property == "XPATH") {

						AndroidDriver.findElement(By.xpath(objectName)).sendKeys(Keys.ENTER);
						tsStatus = "Done";
					}
				} else if (eventType == "SETTEXT") {

					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
										
					if (String.valueOf(Cur_TestData) == "null") {
						Cur_TestData = "";
					} else if (Cur_TestData.toUpperCase().startsWith("DYN_")) {
						log.info("Before Dyn2");
						Get_DynamicValue(Cur_TestData);
						log.info("Dynamic Value1" + Dynamic_TestValue);
						Cur_TestData = Dynamic_TestValue;
					} else if (Cur_TestData.toUpperCase().startsWith("ENV_")) {
						Get_EnvironmentValue(Cur_TestData);
						Cur_TestData = Dynamic_TestValue;
					}
					if (ObjectClass.equalsIgnoreCase("seltext")) {
						if (str_Property == "ID") {
							element = AndroidDriver.findElement(By.id(objectName));
							element.clear();
							element.sendKeys(Cur_TestData);
							testData = Cur_TestData;
							tsStatus = "Done";
						} else if (str_Property == "NAME") {
							element = AndroidDriver.findElement(By.name(objectName));
							element.clear();
							element.sendKeys(Cur_TestData);
							testData = Cur_TestData;
							tsStatus = "Done";

						} else if (str_Property == "XPATH") {
							element = AndroidDriver.findElement(By.xpath(objectName));
							element.clear();
							element.sendKeys(Cur_TestData);
							testData = Cur_TestData;
							tsStatus = "Done";
						}
					}
				} else if (eventType == "SELECT") {

					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (String.valueOf(Cur_TestData) == "null") {
						Cur_TestData = "";
					} else {
						if (Cur_TestData.toUpperCase().startsWith("DYN_")) {
							Get_DynamicValue(Cur_TestData);
							Cur_TestData = Dynamic_TestValue;
						}
					}
					if (str_Property == "ID") {

						Select oSelect = new Select(AndroidDriver.findElement(By.id(objectName)));
						oSelect.selectByVisibleText(Cur_TestData);
						AndroidDriver.findElement(By.id(objectName)).click();
						testData = Cur_TestData;
						tsStatus = "Done";

					} else if (str_Property == "NAME") {
						Select se = new Select(AndroidDriver.findElement(By.name(objectName)));
						se.selectByVisibleText(Cur_TestData);
						AndroidDriver.findElement(By.name(objectName)).click();
						testData = Cur_TestData;
						tsStatus = "Done";

					} else if (str_Property == "XPATH") {
						Select se = new Select(AndroidDriver.findElement(By.xpath(objectName)));
						se.selectByVisibleText(Cur_TestData);
						AndroidDriver.findElement(By.xpath(objectName)).click();
						testData = Cur_TestData;
						tsStatus = "Done";
					}
				}

				else if (eventType == "VERIFY") {
					String result = "";
					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (String.valueOf(Cur_TestData) == "null") {
						Cur_TestData = "";
					}
					KeywordName = "Verify_" + KeywordName;
					if (str_Property == "ID") {
						AndroidElement element1 = AndroidDriver.findElement(By.id(objectName));
						result = element1.getText();
						testData = Cur_TestData;
					} else if (str_Property == "NAME") {
						AndroidElement element1 = AndroidDriver.findElement(By.name(objectName));
						result = element1.getText();
						testData = Cur_TestData;
					} else if (str_Property == "XPATH") {
						AndroidElement element1 = AndroidDriver.findElement(By.xpath(objectName));
						result = element1.getText();
						testData = Cur_TestData;
					}
					ActualTestDataValue = result;
					if (ActualTestDataValue.trim().equals(testData.trim())) {
						tsStatus = "Pass";
					} else {
						pub_getTestcaseStatus = "Failed";
						pub_getIterationStatus = "Failed";
						tsStatus = "Fail";
						TestcaseFinalStatus = "Fail";
						tcStatus = "Fail";
					}
				}
				sno++;
				result(KeywordName, testData, tsStatus, Cur_objectId, subIteration, eventType);
				ActualTestDataValue = "";
				Loggerupdator("Keyword Performed  :" + KeywordName + "\n Test Data :" + testData + "\n Status: "
						+ tsStatus + "\n eventType " + eventType, "Android_Automation", 1, "");

			}

		} catch (Exception ex) {
			Loggerupdator("Keyword " + KeywordName + " is not performed", "Android_Automation", 0, ex.toString());
			checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, ex.toString());

		}

	}
	
	public void IOS_automation(String Screen_ID, String objectName, String ObjectClass, String eventType,
			String Cur_objectId, int subIteration, String KeywordName, String str_Property) {

		try {

			if (tcStatus != "Fail") {
				if (sno == 0) {
					writeIterationHTML("");
				}
				Pub_dynamicValue = "";
				ActualTestDataValue = "";
				String testData = "";
				tsStatus = "Done";
				IOSElement element = null;
				if (ObjectClass == "DYNAMIC") {

					if (str_Property == "ID") {

						element = IOSdriver.findElement(By.id(objectName));
					} else if (str_Property == "XPATH") {

						element = IOSdriver.findElement(By.xpath(objectName));
					} else if (str_Property == "NAME") {

						element = IOSdriver.findElement(By.name(objectName));
					}

					if (eventType == "SETTEXT") {
						String Dyn_Data = element.getAttribute("value");

						Func_UpdateDynamicValue(KeywordName, Dyn_Data);
					} else if (eventType == "CLICK") {
						String Dyn_Data = element.getText().trim();
						Func_UpdateDynamicValue(KeywordName, Dyn_Data);
						Loggerupdator("Performed Dynamic Operation :" + KeywordName, "Func_MainNew", 2, "");
					} else {
						String Dyn_Data = element.getText().trim();
						Func_UpdateDynamicValue(KeywordName, Dyn_Data);
						Loggerupdator("Performed Dynamic Operation :" + KeywordName, "Func_MainNew", 2, "");
					}
				}

				else if (eventType == "CLICK") {
					if (ObjectClass.equalsIgnoreCase("selclick")) {
						if (str_Property == "ID") {
							IOSdriver.findElement(By.id(objectName)).click();
							tsStatus = "Done";
						} else if (str_Property == "NAME") {
							IOSdriver.findElement(By.name(objectName)).click();
							tsStatus = "Done";
						} else if (str_Property == "XPATH") {
							IOSdriver.findElement(By.xpath(objectName)).click();
							tsStatus = "Done";
						}
					} else if (str_Property == "CONTEXT") {
						((ContextAware) IOSdriver).context(objectName);
						tsStatus = "Done";
					}
				}

				else if (eventType == "ENTER") {

					if (str_Property == "ID") {
						IOSdriver.findElement(By.id(objectName)).sendKeys(Keys.ENTER);
						tsStatus = "Done";
					} else if (str_Property == "NAME") {
						IOSdriver.findElement(By.name(objectName)).sendKeys(Keys.ENTER);
						tsStatus = "Done";
					} else if (str_Property == "XPATH") {
						IOSdriver.findElement(By.xpath(objectName)).sendKeys(Keys.ENTER);
						tsStatus = "Done";
					}
				}

				else if (eventType == "DATE") {

					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (str_Property == "XPATH") {

						String day = Cur_TestData.split("-")[0];
						String month = Cur_TestData.split("-")[1];
						String year = Cur_TestData.split("-")[2];
						IOSdriver.findElement(By.id(objectName)).click();

						try {
							((ContextAware) IOSdriver).context("NATIVE_APP");
							List<IOSElement> wheels = (List<IOSElement>) IOSdriver
									.findElements(By.className("XCUIElementTypePickerWheel"));
							wheels.get(0).sendKeys(day);
							wheels.get(1).sendKeys(month);
							((MobileElement) wheels.get(2)).setValue(year);
							testData = Cur_TestData;
							tsStatus = "Done";
						} catch (Exception ex) {

						}
					} else if (str_Property == "NAME") {

						String day = Cur_TestData.split("-")[0];
						String month = Cur_TestData.split("-")[1];
						String year = Cur_TestData.split("-")[2];
						IOSdriver.findElement(By.id(objectName)).click();
						
							((ContextAware) IOSdriver).context("NATIVE_APP");
							List<IOSElement> wheels = (List<IOSElement>) IOSdriver
									.findElements(By.className("XCUIElementTypePickerWheel"));
							wheels.get(0).sendKeys(day);
							wheels.get(1).sendKeys(month);
							((MobileElement) wheels.get(2)).setValue(year);
							testData = Cur_TestData;
							tsStatus = "Done";
						

					} else if (str_Property == "ID") {

						String day = Cur_TestData.split("-")[0];
						String month = Cur_TestData.split("-")[1];
						String year = Cur_TestData.split("-")[2];
						IOSdriver.findElement(By.id(objectName)).click();
						
							((ContextAware) IOSdriver).context("NATIVE_APP");
							List<IOSElement> wheels = (List<IOSElement>) IOSdriver
									.findElements(By.className("XCUIElementTypePickerWheel"));
							wheels.get(0).sendKeys(day);
							wheels.get(1).sendKeys(month);
							((MobileElement) wheels.get(2)).setValue(year);
							((ContextAware) IOSdriver).context("WEBVIEW_1");
							testData = Cur_TestData;
							tsStatus = "Done";
						
					}
				} else if (eventType == "SETTEXT") {

					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (String.valueOf(Cur_TestData).toUpperCase().equalsIgnoreCase("NODATA")) {
						Cur_TestData = "";
					} else if (Cur_TestData.toUpperCase().startsWith("DYN_")) {
						log.info("Before Dyn2");
						Get_DynamicValue(Cur_TestData);
						log.info("Dynamic Value1" + Dynamic_TestValue);
						Cur_TestData = Dynamic_TestValue;
					} else if (Cur_TestData.toUpperCase().startsWith("ENV_")) {
						Get_EnvironmentValue(Cur_TestData);
						Cur_TestData = Dynamic_TestValue;
					}
					if (ObjectClass.equalsIgnoreCase("seltext")) {
						if (str_Property == "ID") {
							IOSdriver.findElement(By.id(objectName)).sendKeys(Cur_TestData);
							testData = Cur_TestData;
							tsStatus = "Done";

						} else if (str_Property == "NAME") {
							IOSdriver.findElement(By.name(objectName)).sendKeys(Cur_TestData);
							testData = Cur_TestData;
							tsStatus = "Done";

						} else if (str_Property == "XPATH") {
							IOSdriver.findElement(By.xpath(objectName)).sendKeys(Cur_TestData);
							testData = Cur_TestData;
							tsStatus = "Done";
						}

					} else if (ObjectClass.equalsIgnoreCase("selautotext")) {

						 Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
						if (String.valueOf(Cur_TestData) == "null") {
							Cur_TestData = "";
						} else if (Cur_TestData.toUpperCase().startsWith("DYN_")) {
							log.info("Before Dyn2");
							Get_DynamicValue(Cur_TestData);
							log.info("Dynamic Value1" + Dynamic_TestValue);
							Cur_TestData = Dynamic_TestValue;
						} else if (Cur_TestData.toUpperCase().startsWith("ENV_")) {
							Get_EnvironmentValue(Cur_TestData);
							Cur_TestData = Dynamic_TestValue;
						}
						if (str_Property == "ID") {
							IOSdriver.findElement(By.id(objectName)).sendKeys(Cur_TestData);
							IOSdriver.findElement(By.xpath("//*[@title='" + Cur_TestData + "']")).click();
							testData = Cur_TestData;
							tsStatus = "Done";
						} else if (str_Property == "NAME") {
							IOSdriver.findElement(By.name(objectName)).sendKeys(Cur_TestData);
							IOSdriver.findElement(By.xpath("//*[@title='" + Cur_TestData + "']")).click();
							testData = Cur_TestData;
							tsStatus = "Done";
						} else if (str_Property == "XPATH") {
							IOSdriver.findElement(By.xpath(objectName)).sendKeys(Cur_TestData);
							IOSdriver.findElement(By.xpath("//*[@title='" + Cur_TestData + "']")).click();

							testData = Cur_TestData;
							tsStatus = "Done";
						}

					} else if (ObjectClass.equalsIgnoreCase("selswipe")) {

						if (str_Property == "TOUCH") {
							 Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
							int x = Integer.parseInt(Cur_TestData.split(",")[0]);
							int y = Integer.parseInt(Cur_TestData.split(",")[1]);
							int x1 = Integer.parseInt(Cur_TestData.split(",")[2]);
							int y1 = Integer.parseInt(Cur_TestData.split(",")[3]);
							/** add swipe command **/
						}
					} else if (ObjectClass == "selverifytext") {
						 Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
						if (str_Property == "ID") {

							 Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
							int status = IOSdriver.findElements(By.id(Cur_TestData)).size();
							if (status > 0) {
								testData = Cur_TestData;
								tsStatus = "Done";
							}
						} else if (str_Property == "NAME") {

							 Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
							int status = IOSdriver.findElements(By.name(Cur_TestData)).size();
							if (status > 0) {
								testData = Cur_TestData;
								tsStatus = "Done";
							}
						} else if (str_Property == "XPATH") {

							 Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
							int status = IOSdriver.findElements(By.xpath(Cur_TestData)).size();
							if (status > 0) {
								testData = Cur_TestData;
								tsStatus = "Done";
							}
						}
					}
				}

				else if (eventType == "SELECT") {

					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (String.valueOf(Cur_TestData) == "null") {
						Cur_TestData = "";
					} else {
						if (Cur_TestData.toUpperCase().startsWith("DYN_")) {
							Get_DynamicValue(Cur_TestData);
							Cur_TestData = Dynamic_TestValue;
						}
					}
					if (str_Property == "ID") {

						Select oSelect = new Select(IOSdriver.findElement(By.id(objectName)));
						oSelect.selectByVisibleText(Cur_TestData);
						IOSdriver.findElement(By.id(objectName)).click();
						testData = Cur_TestData;
						tsStatus = "Done";
					} else if (str_Property == "NAME") {
						Select se = new Select(IOSdriver.findElement(By.name(objectName)));
						se.selectByVisibleText(Cur_TestData);
						IOSdriver.findElement(By.name(objectName)).click();
						testData = Cur_TestData;
						tsStatus = "Done";

					} else if (str_Property == "XPATH") {
						Select se = new Select(IOSdriver.findElement(By.xpath(objectName)));
						se.selectByVisibleText(Cur_TestData);
						IOSdriver.findElement(By.xpath(objectName)).click();
						testData = Cur_TestData;
						tsStatus = "Done";
					}
				} else if (eventType == "EXIST") {
					if (str_Property == "ID")

					{
						if (IOSdriver.findElements(By.id(objectName)).size() != 0) {
							tsStatus = "Pass";
						} else {
							checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "");
						}
					} else if (str_Property == "NAME") {
						if (IOSdriver.findElements(By.name(objectName)).size() != 0) {
							tsStatus = "Pass";
						} else {
							checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "");
						}
					} else if (str_Property == "XPATH") {
						if (IOSdriver.findElements(By.xpath(objectName)).size() != 0) {
							tsStatus = "Pass";
						} else {
							checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "");
						}
					}
				} else if (eventType == "VERIFY") {
					String result = "";
					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					if (String.valueOf(Cur_TestData) == "null") {
						Cur_TestData = "";
					}
					KeywordName = "Verify_" + KeywordName;
					if (str_Property == "ID") {

						IOSElement element1 = IOSdriver.findElement(By.id(objectName));
						result = element1.getText();
						testData = Cur_TestData;

					} else if (str_Property == "NAME") {

						IOSElement element1 = IOSdriver.findElement(By.name(objectName));
						result = element1.getText();
						testData = Cur_TestData;
					} else if (str_Property == "XPATH") {
						IOSElement element1 = IOSdriver.findElement(By.xpath(objectName));
						result = element1.getText();
						testData = Cur_TestData;
					}
					ActualTestDataValue = result;
					if (ActualTestDataValue.trim().equals(testData.trim())) {
						tsStatus = "Pass";
					} else {
						pub_getTestcaseStatus = "Failed";
						pub_getIterationStatus = "Failed";
						tsStatus = "Fail";
						TestcaseFinalStatus = "Fail";
						tcStatus = "Fail";
					}
				}
				sno++;
				result(KeywordName, testData, tsStatus, Cur_objectId, subIteration, eventType);
				ActualTestDataValue = "";
				Loggerupdator("Keyword Performed  :" + KeywordName + "\n Test Data :" + testData + "\n Status: "
						+ tsStatus + "\n eventType " + eventType, "IOS_Automation", 1, "");

			}
		} catch (Exception ex) {
			Loggerupdator("Keyword " + KeywordName + " is not performed", "IOS_Automation", 0, ex.toString());
			checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, ex.toString());

		}
	}
	
	public void Terminal_automation(String Screen_ID, String objectName, String ObjectClass, String eventType,
			String Cur_objectId, int subIteration, String KeywordName, String str_Property) {
		
		try {

			String strSts = null;
			strSts = "Done";
			String strActualData = null;
			strActualData = "";
			Pub_dynamicValue = "";
			ActualTestDataValue = "";
			Dynamic_TestValue="";
			String strTestData = null;
			strTestData = "";
			String[] a = null;

			if (tcStatus != "Fail") {

				if (sno == 0) {
					writeIterationHTML("");
				}
				Thread.sleep(1000);
				if (Terminaltype.toUpperCase().contains("HOD")) {
					switch (eventType.toUpperCase()) {
					case "VERIFY":
						switch (str_Property.toUpperCase()) {
						case "XPATH":
							if (objectName.indexOf("T:G") + 1 > 0) {
								// Getting Local Input Data
								String fnGetTestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
								if (fnGetTestData.toUpperCase().contains("DYN_")) {
									Get_DynamicValue(fnGetTestData);
									fnGetTestData = Dynamic_TestValue;

								}
								strTestData = fnGetTestData;
								if (!strTestData.equalsIgnoreCase("NODATA")) {
									// Getting Screen Data
									a = objectName.substring(3).split("[,]");
									// WScript.Sleep(1000)
									int csrval = fnCalculateCursor(Integer.parseInt(a[0]), Integer.parseInt(a[1]));
									String csr = csrval + "###" + a[2];
									// WScript.Sleep(1000)
									String LstrActualData = fnReadStringHOD(csr);
									 strActualData = LstrActualData.trim().substring(0, Integer.parseInt(a[2]));
									 strActualData=ActualTestDataValue;
									if (fnGetTestData.contentEquals(strActualData)) {
										strSts = "Pass";
									} else {
										strSts = "Fail";
									}
								}
							}
							break;
						}
						break;
					case "SETTEXT":
						switch (str_Property.toUpperCase()) {
						case "XPATH":
							if (objectName.equals("W:Input")) {

								String fnGetTestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
								if (fnGetTestData.toUpperCase().contains("DYN_")) {
									Get_DynamicValue(fnGetTestData);
									fnGetTestData = Dynamic_TestValue;
								}
								strTestData = fnGetTestData;
								if (!strTestData.equals("NODATA")) {
									// objWScriptShell.Sendkeys strTestData;
									fnWSscript(strTestData);
								}
							} else if (objectName.indexOf("T:S") + 1 > 0) {

								String varDataDynamicValue=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
								if (varDataDynamicValue.toUpperCase().contains("DYN_")) {
									Get_DynamicValue(varDataDynamicValue);
									varDataDynamicValue = Dynamic_TestValue;
								}
								strTestData = varDataDynamicValue;
								if (!strTestData.equals("NODATA")) {
									a = objectName.substring(3).split("[,]");

									int csrval = fnCalculateCursor(Integer.parseInt(a[0]), Integer.parseInt(a[1]));
									String csr = csrval + "###" + a[2];

									fnSendCursorHOD_2(csr);
									fnSendKeysHOD(strTestData.replace("@", "@@"));
								}
							}
							break;
						}
						break;
					case "CLICK":
						switch (str_Property.toUpperCase()) {
						case "XPATH":
							
							Thread.sleep(2000);
							if (objectName.equals("W:Tab")) {
								// objWScriptShell.Sendkeys("{Tab}");
								fnWSscript("{Tab}");

							} else if (objectName.equals("W:Enter")) {
								// objWScriptShell.Sendkeys("{Enter}");
								fnWSscript("{Enter}");

							} else if (objectName.equals("W:ALTF")) {
								// objWScriptShell.Sendkeys "%(f)";
								fnWSscript("%(f)");
							} else if (objectName.equals("W:L")) {
								// objWScriptShell.Sendkeys "(l)";
								fnWSscript("(l)");
							} else if (objectName.equals("W:Arrow")) {
								// objWScriptShell.Sendkeys "{RIGHT}";
								fnWSscript("{RIGHT}");
							} else if (objectName.equals("W:F4")) {
								// objWScriptShell.Sendkeys "%{F4}";
								fnWSscript("%{F4}");

								// Terminal Commands
							} else if (objectName.equals("T:BackTab")) {
								fnSendKeysHOD("@B");
							} else if (objectName.equals("T:Clear")) {
								fnSendKeysHOD("@C");
							}

							else if (objectName.equals("T:Delete")) {
								fnSendKeysHOD("@D");
							} else if (objectName.equals("T:Enter")) {
								fnSendKeysHOD("@E");
							} else if (objectName.equals("T:EraseEndOfField")) {
								fnSendKeysHOD("@F");
							} else if (objectName.equals("T:Help")) {
								fnSendKeysHOD("@H");
							} else if (objectName.equals("T:Insert")) {
								fnSendKeysHOD("@I");
							} else if (objectName.equals("T:Jump")) {
								fnSendKeysHOD("@J");
							} else if (objectName.equals("T:Left")) {
								fnSendKeysHOD("@L");
							} else if (objectName.equals("T:NewLine")) {
								fnSendKeysHOD("@N");
							} else if (objectName.equals("T:Space")) {
								fnSendKeysHOD("");
							} else if (objectName.equals("T:Print")) {
								fnSendKeysHOD("@A@T");
							} else if (objectName.equals("T:Reset")) {
								fnSendKeysHOD("@R");
							} else if (objectName.equals("T:Tab")) {
								fnSendKeysHOD("@T");
							} else if (objectName.equals("T:Up")) {
								fnSendKeysHOD("@U");
							} else if (objectName.equals("T:Down")) {
								fnSendKeysHOD("@V");
							} else if (objectName.equals("T:Right")) {
								fnSendKeysHOD("@Z");
							} else if (objectName.equals("T:Home")) {
								fnSendKeysHOD("@0");
							} else if (objectName.equals("T:PF1")) {
								fnSendKeysHOD("@1");
							} else if (objectName.equals("T:PF2")) {
								fnSendKeysHOD("@2");
							} else if (objectName.equals("T:PF3")) {
								fnSendKeysHOD("@3");
							} else if (objectName.equals("T:PF4")) {
								fnSendKeysHOD("@4");
							} else if (objectName.equals("T:PF5")) {
								fnSendKeysHOD("@5");
							} else if (objectName.equals("T:PF6")) {
								fnSendKeysHOD("@6");
							} else if (objectName.equals("T:PF7")) {
								fnSendKeysHOD("@7");
							} else if (objectName.equals("T:PF8")) {
								fnSendKeysHOD("@8");
							} else if (objectName.equals("T:PF9")) {
								fnSendKeysHOD("@9");
							} else if (objectName.equals("T:PF10")) {
								fnSendKeysHOD("@a");
							} else if (objectName.equals("T:PF11")) {
								fnSendKeysHOD("@b");
							} else if (objectName.equals("T:PF12")) {
								fnSendKeysHOD("@c");
							} else if (objectName.equals("T:PF13")) {
								fnSendKeysHOD("@d");
							} else if (objectName.equals("T:PF14")) {
								fnSendKeysHOD("@e");
							} else if (objectName.equals("T:PF15")) {
								fnSendKeysHOD("@f");
							} else if (objectName.equals("T:PF16")) {
								fnSendKeysHOD("@g");
							} else if (objectName.equals("T:PF17")) {
								fnSendKeysHOD("@h");
							} else if (objectName.equals("T:PF18")) {
								fnSendKeysHOD("@i");
							} else if (objectName.equals("T:PF19")) {
								fnSendKeysHOD("@j");
							} else if (objectName.equals("T:PF20")) {
								fnSendKeysHOD("@k");
							} else if (objectName.equals("T:PF21")) {
								fnSendKeysHOD("@l");
							} else if (objectName.equals("T:PF22")) {
								fnSendKeysHOD("@m");
							} else if (objectName.equals("T:PF23")) {
								fnSendKeysHOD("@n");
							} else if (objectName.equals("T:PF24")) {
								fnSendKeysHOD("@o");
							} else if (objectName.equals("T:PageUp")) {
								fnSendKeysHOD("@u");
							} else if (objectName.equals("T:PageDown")) {
								fnSendKeysHOD("@v");
							} else if (objectName.equals("T:PA1")) {
								fnSendKeysHOD("@x");
							} else if (objectName.equals("T:PA2")) {
								fnSendKeysHOD("@y");
							} else if (objectName.equals("T:PA3")) {
								fnSendKeysHOD("@z");
							} else if (objectName.equals("T:PA4")) {
								fnSendKeysHOD("@+");
							} else if (objectName.equals("T:PA5")) {
								fnSendKeysHOD("@%");
							} else if (objectName.equals("T:PA6")) {
								fnSendKeysHOD("@&");
							} else if (objectName.equals("T:PA7")) {
								fnSendKeysHOD("@'");
							} else if (objectName.equals("T:PA8")) {
								fnSendKeysHOD("@(");
							} else if (objectName.equals("T:PA9")) {
								fnSendKeysHOD("@)");
							} else if (objectName.equals("T:PA10")) {
								fnSendKeysHOD("@*");
							} else if (objectName.equals("T:Test")) {
								fnSendKeysHOD("@A@C");
								// ' ElseIf objectName="T:WordDelete"Then
								// ' fnSendKeysHOD ""
							} else if (objectName.equals("T:FieldExit")) {
								fnSendKeysHOD("@A@E");
							} else if (objectName.equals("T:EraseInput")) {
								fnSendKeysHOD("@A@F");
							} else if (objectName.equals("T:SystemRequest")) {
								fnSendKeysHOD("@A@H");
							} else if (objectName.equals("T:InsertToggle")) {
								fnSendKeysHOD("@A@I");
							} else if (objectName.equals("T:CursorSelect")) {
								fnSendKeysHOD("@A@J");
							} else if (objectName.equals("T:CursorLeftFast")) {
								fnSendKeysHOD("@A@L");
							} else if (objectName.equals("T:Attention")) {
								fnSendKeysHOD("@A@Q");
								// 'ElseIf objectName="T:DeviceCancel"Then
								// ' fnSendKeysHOD ""
							} else if (objectName.equals("T:CursorUpFast")) {
								fnSendKeysHOD("@A@U");
							} else if (objectName.equals("T:CursorDownFast")) {
								fnSendKeysHOD("@A@V");
							} else if (objectName.equals("T:Hex")) {
								fnSendKeysHOD("@A@X");
							} else if (objectName.equals("T:CursorRightFast")) {
								fnSendKeysHOD("@A@Z");
							} else if (objectName.equals("T:@")) {
								fnSendKeysHOD("@@");
							} else if (objectName.equals("T:Alt")) {
								fnSendKeysHOD("@A");
							} else if (objectName.equals("T:Cmd")) {
								fnSendKeysHOD("@A@Y");
							} else if (objectName.equals("T:Duplicate")) {
								fnSendKeysHOD("@S@x");
							} else if (objectName.equals("T:End")) {
								fnSendKeysHOD("@q");
							} else if (objectName.equals("T:FieldMark")) {
								fnSendKeysHOD("@S@y");
							} else if (objectName.equals("T:FieldMinus")) {
								fnSendKeysHOD("@A@-");
							} else if (objectName.equals("T:FieldPlus")) {
								fnSendKeysHOD("@A@+");
							} else if (objectName.equals("T:PrintPC")) {
								fnSendKeysHOD("@A@t");
							} else if (objectName.equals("T:ForwardWordTab")) {
								fnSendKeysHOD("@A@y");
							} else if (objectName.equals("T:BackwardWordTab")) {
								fnSendKeysHOD("@A@z");
							} else if (objectName.equals("T:RecordBackspace")) {
								fnSendKeysHOD("@A@<");
							} else if (objectName.equals("T:ForwardCharacter")) {
								fnSendKeysHOD("@X@7");
							} else if (objectName.equals("T:AlternateCursor")) {
								fnSendKeysHOD("@$");
							} else if (objectName.equals("T:Backspace")) {
								fnSendKeysHOD("@<");
							} else if (objectName.equals("T:LPrint")) {
								fnSendKeysHOD("@P");
							} else if (objectName.indexOf("C:") + 1 > 0) {
								// 'fnWriteLog(Mid(objectName,3))
								a = objectName.substring(2).split("[,]", -1);
								int csr = fnCalculateCursor(Integer.parseInt(a[0]), Integer.parseInt(a[1]));
								fnSendCursorHOD(csr);
							}
						}
					}
				}
			}

			// check verify Fail Or Not

			if (strSts.equalsIgnoreCase("Fail")) {
				Loggerupdator("Keyword " + KeywordName + " is not performed", "Terminal_automation", 0,
						"Could not perform the Action to Terminal");
				checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, "Error");
			} else {
				sno++;
				result(KeywordName, strTestData, strSts, Cur_objectId, subIteration, eventType);
				ActualTestDataValue = "";
				Loggerupdator("Keyword Performed  :" + KeywordName + "\n Test Data :" + strTestData + "\n Status: "
						+ strSts + "\n eventType " + eventType, "Terminal_automation", 1, "");
			}
		} catch (Exception ex) {
			Loggerupdator("Keyword " + KeywordName + " is not performed", "Terminal_automation", 0, ex.toString());
			checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, ex.toString());
		}
	}
	
	/*********************************************************************************************/
	            /** AS400 Terminal Function List ***/	
	/*********************************************************************************************/

	public String fnExecuteTerminal(String paramData) {
		StringBuilder output = null;
		ProcessBuilder processBuilder = new ProcessBuilder();
		String[] cmd = { "C:\\Reference\\EHLLAPI_CMD.exe", paramData };
		processBuilder.command(cmd);
		try {
			Process process = processBuilder.start();
			 output = new StringBuilder();
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				output.append(line + "\n");
			}
			int exitVal = process.waitFor();
			if (exitVal == 0) {
				System.out.println("Success!");
				System.out.println(output);
			} 
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return output.toString();
	}
		
	public static int fnCalculateCursor(int paramDataY, int paramDataX) {
		int y = paramDataY;
		int x = paramDataX;
		y = (y - 1) * 80;
		return y + x;
	}
	public String fnReadStringHOD(String paramSKey) {

		String varHODStatusCode = fnExecuteTerminal("RS=" + paramSKey.toString());

		if (varHODStatusCode.indexOf("###") > 0) {
			String[] objArrayData = varHODStatusCode.split("###");
			return objArrayData[1];
		} else {
			varHODStatusCode = fnExecuteTerminal("RS=" + paramSKey.toString());
			if (varHODStatusCode.indexOf("###") > 0) {
				String[] objArrayData = varHODStatusCode.split("###");
				return objArrayData[1];
			}
		}
		return "";
	}

	public  void fnSendCursorHOD(int paramSKey) {
		String varHODStatusCode = fnExecuteTerminal("SC=" + paramSKey);
	}
	public  void fnSendCursorHOD_2(String paramSKey) {
		String varHODStatusCode = fnExecuteTerminal("SC=" + paramSKey);
	}

	private  void fnSendKeysHOD(String paramSKey) {
		String varHODStatusCode = fnExecuteTerminal("SK=" + paramSKey.toString());
	}
	
	private  void fnWaitHOD(String paramSKey) {
		String varHODStatusCode = fnExecuteTerminal("WT=" + paramSKey.toString());
	}
	
	private void fnWSscript(String paramSKey) {
		try {
			Runtime.getRuntime().exec(paramSKey);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
		
	// Load Testdata for current testcase and iteration
	public void loadRiderTestData() {

		String qryGetTestData = "";
		try {

			log.info("*******************************************************************");
			log.info("Iteration " + pub_Cur_Iteration + " Started");
			log.info("*******************************************************************");
			tcStatus = "Pass";
			pub_getIterationStatus = "Passed";

			// Get Test Data Values
			/************************************************************************************/
			if (Pub_DefaultBrowserName.equalsIgnoreCase("Terminal")) {

				qryGetTestData = "SELECT * FROM tbl_IterationMapping where testcaseid = "
						+ Integer.parseInt(varRiderTestCaseID)
						+ " and iterationid = (SELECT IterationId FROM tbl_Iteration WHERE TestcaseID= "
						+ Integer.parseInt(varRiderTestCaseID) + "" + " AND IterationNumber= "
						+ Integer.parseInt(pub_Cur_Iteration) + " and ProductNameID=" + Integer.parseInt(ProductID)
						+ " " + "and RiderCodeNameID=" + varRiderIteration + " and TCMasterID=" + pubTestCaseID + ")";

				JSONArray jsondata = RestApicall(qryGetTestData);
				_Ridertestdata = new HashMap<String, String>();
				for (int i = 0; i <= jsondata.length() - 1; i++) {

					JSONObject rs = jsondata.getJSONObject(i);
					int objId = rs.getInt("objID");
					int subId = rs.getInt("SubIterationID");
					String strObjectMap = objId + "_" + subId;

					String strTestData = rs.getString("InputData");

					if (strTestData == null || strTestData == "") {
						_Ridertestdata.put(strObjectMap, "");
					} else {
						_Ridertestdata.put(strObjectMap, strTestData);
					}
				}
			}
		} catch (Exception e) {
			Loggerupdator("Failed to load loadTestData Query: " + qryGetTestData, "loadTestData", 0, e.toString());
		}
	}
	
	// Get Description for Rider Test description
	public void RiderloadTestStepDesc() {

		String qryGetTestData = "";
		try {

			qryGetTestData = "SELECT * FROM tbl_TestStepDescription WHERE testcaseid = "
					+ Integer.parseInt(varRiderTestCaseID) + "";
			JSONArray rs1 = RestApicall(qryGetTestData);
			if (rs1.length() > 0) {
				_RiderTestStepDesc = new HashMap<String, String>();
				for (int i = 0; i <= rs1.length() - 1; i++) {
					JSONObject rs = rs1.getJSONObject(i);
					String strObjectMap = rs.getInt("ObjectID") + "_" + rs.getInt("SubIteration");
					String strTestStepDesc = rs.getString("TestStep_Desc");
					if (strTestStepDesc == null || strTestStepDesc == "" || strTestStepDesc == "null") {
						_RiderTestStepDesc.put(strObjectMap, "");
					} else {
						_RiderTestStepDesc.put(strObjectMap, strTestStepDesc);
					}
				}
			}

		} catch (Exception e) {
			Loggerupdator("Failed to load loadTestStepDesc Query: " + qryGetTestData, "loadTestStepDesc", 0,
					e.toString());
			System.out.println("Error: " + e);
		}
	}
	
	public void fnRiderSelection(String Param) {

		try {
			_ItsRiderFlowTC = 1;
			String[] varRiderListArray = Param.split(";");

			HashMap<String, Integer> objDictRiderStatus = new HashMap<String, Integer>();
			objDictRiderStatus.clear();

			for (String _Rider : varRiderListArray) {
				objDictRiderStatus.put(_Rider, 0);
			}

			int strPageCounter = 0;
			int strPageDownAvailable = fnRiderCheckIfPageDown();
			int strPageFlag = 0;

			while (!(strPageCounter > 0 && strPageDownAvailable == 0)) {
				for (String obj : varRiderListArray) {
					for (int Row = 8; Row <= 21; Row++) {
						if (fnRiderCheckExistInPosition(obj, Row) == 1) {
							fnRiderSelect(Row);
						}
					}
				}
				if (strPageDownAvailable == 1) {
					fnSendKeysHOD("@v");
					strPageDownAvailable = fnRiderCheckIfPageDown();
					if (strPageDownAvailable == 0 && strPageFlag == 0) {
						strPageDownAvailable = 1;
						strPageFlag = 1;
					}
					strPageCounter = strPageCounter + 1;
				} else {
					strPageCounter = strPageCounter + 1;
				}
			}
			result("Verify Default Component Selected In Select_Cover_Required Screen", Param, "Pass", "2471", 1, "VERIFY");  	
	    	fnSendKeysHOD("@E");
			result("Click the Keypress_Enter_Terminal button", "", "Done", "1111", 1, "CLICK");  	

			fnGetRiderFunctions(Param);
			for (String Rider : varRiderListArray) {

				// wait time
				varRiderTestCaseName = varDictRiderWithTestcase.get(Rider);
				varRiderTestCaseID = varDictRiderWithValue.get(Rider);
				varRiderIteration = varDictRiderWithIteration.get(Rider);
				String strTestLibraryName = "";
				String riderscript = fnRiderGetTestScript(varRiderTestCaseName, PubApplicationID);
				loadRiderTestData();
				RiderloadTestStepDesc();

				// Generate the Test ApplicationLibrary Name
				strTestLibraryName = PubApplicationName + "_" + PubApplicationID + "_ApplicationLibrary";

				List<String> pubRiderBusinessKeywordsList = new ArrayList<>();

				pubRiderBusinessKeywordsList = funRiderFlowScriptGenerate(riderscript);

				// Looping Business Keywords from a Array List
				for (String temp : pubRiderBusinessKeywordsList) {
					String aClass = "SeleniumProject." + strTestLibraryName;
					String[] arrOfStr = temp.split("\\(");
					String aMethod = arrOfStr[0].trim();
					Class params[] = {};
					Object paramsObj[] = {};

					Class thisClass = Class.forName(aClass);
					Object iClass = thisClass.newInstance();
					// Method thisMethod = thisClass.getDeclaredMethod(aMethod,
					// params);
					Method thisMethod = thisClass.getDeclaredMethod(aMethod, int.class);
					// Method gs1Method =
					// thisClass.getMethod("publicSum",int.class,int.class);
					thisMethod.invoke(iClass, Integer.parseInt(arrOfStr[1]));
					System.out.println(temp);
				}				
				_ItsRiderFlowTC=0;
			}

		} catch (InstantiationException ex) {
			_ItsRiderFlowTC=0;
			System.err.println("Not able to create Instance of Class");
		} catch (IllegalAccessException ex) {
			System.err.println("Not able to access Class");
		} catch (ClassNotFoundException ex) {
			System.err.println("Not able to find Class");
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	
	public List<String> funRiderFlowScriptGenerate(String strScript) {
		// Split Strings and collect into array
		String[] arrOfStr = strScript.split("\n");
		// List to collect the Business Keywords
		List<String> myList = new ArrayList<>();
		try {
			// Looping array list and grab the Business Keywords (identified by k1. starts
			// with)
			for (String a : arrOfStr)

				if (a.trim().startsWith("kl.")) {
					myList.add(a.trim().replace("kl.", "").replace(");", ""));
				}
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return myList;
	}
	
	private String fnRiderGetTestScript(String strTCName, String pubApplicationID2) {

		String strQuery = "";
		String varTestScript = "";
		try {
			strQuery = "select TestScript from tbl_Testcase where TestcaseName = '" + strTCName
					+ "' and ApplicationID ='" + pubApplicationID2 + "'";
			JSONArray jsondata = RestApicall(strQuery);
			for (int i = 0; i <= jsondata.length() - 1; i++) {
				JSONObject rs = jsondata.getJSONObject(i);
				varTestScript += rs.getString("TestScript");
			}

		} catch (Exception ex) {
			System.out.println(ex);
		}
		return varTestScript;
	}

	private int fnRiderCheckIfPageDown() {
		String strReadData = fnReadStringHOD(fnCalculateCursor(21, 79) + "###" + String.valueOf(1));
		if (strReadData.substring(0, 1).equals("+")) {
			return 1;
		} else {
			return 0;
		}
	}
	
	private int fnRiderCheckExistInPosition(String obj, int row) {
		String strReadData = fnReadStringHOD(fnCalculateCursor(row, 20) + "###" + 4);
		if (strReadData.substring(0, 4).equals(obj)) {
			return 1;
		}
		// Verify in Rider Section
		strReadData = fnReadStringHOD(fnCalculateCursor(row, 30) + "###" + String.valueOf(4));
		if (strReadData.substring(0, 4).equals(obj)) {
			return 1;
		}
		return 0;
	}
	
	private void fnRiderSelect(int strRowPosition) {

		try {
			Thread.sleep(1000);
			String strReadData = fnReadStringHOD(fnCalculateCursor(strRowPosition, 9) + "###" + 1);
			String LstrReadData = strReadData.substring(0, 1);

			if (!LstrReadData.equals("X")) {
				int strCursorPosition = fnCalculateCursor(strRowPosition, 9);
				fnSendCursorHOD(strCursorPosition);
				fnSendKeysHOD("X");
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public final  void fnGetRiderFunctions(String strGetRiderCodes)
	{
		 varDictRiderWithValue.clear();
		 varDictRiderWithTestcase.clear();
		 varDictRiderWithIteration.clear();
		 varDictRiderWithAppID.clear();
		 
		String strRiderDetails = strGetRiderCodes.replace(";", ",");

		String strQuery = "select a.ProductID,a.RiderID,a.ApplicationID,a.RiderName,a.RiderCode,a.[RiderTypeID],(select b.TestcaseName from "
			+ "tbl_Testcase b,tbl_ridertestcasemapping c where b.TestcaseID=c.testcaseid and c.ridertypeid=a.ridertypeid AND "
			+ "B.ApplicationID=" + PubApplicationID + ") as [TestcaseName],(select b.TestcaseID from tbl_Testcase b,tbl_ridertestcasemapping c "
		+ "where b.TestcaseID=c.testcaseid and c.ridertypeid=a.ridertypeid AND B.ApplicationID=" + PubApplicationID + ") "
		+ "as [TestcaseID] from tbl_RiderDetails a where a.RiderCode in (" + strRiderDetails + ") and + a.ApplicationID=" +PubApplicationID +";";

			
		JSONArray jsondata= RestApicall(strQuery);				
		for (int i = 0; i <= jsondata.length() - 1; i++) {
			
			JSONObject rs1 = jsondata.getJSONObject(i);
			String strKey="";
            String strValue="";
        
            strKey=rs1.getString("RiderCode");
            strValue=rs1.getString("TestcaseID");
			      
            if(!varDictRiderWithValue.containsKey(strKey)) {
            	varDictRiderWithValue.put(strKey, strValue);
            	strValue=rs1.getString("TestcaseName");
            	varDictRiderWithTestcase.put(strKey, strValue);
            	strValue=rs1.getString("RiderID");
            	varDictRiderWithIteration.put(strKey, strValue);
            	strValue=rs1.getString("ApplicationID");
            	varDictRiderWithAppID.put(strKey, strValue);
            }
		}	   
	}
	
	public void Window_automation(String Screen_ID, String objectName, String ObjectClass, String eventType,
			String Cur_objectId, int subIteration, String KeywordName, String str_Property) {

		try {

			if (tcStatus != "Fail") {
				if (sno == 0) {
					writeIterationHTML("");
				}
				ActualTestDataValue = "";
				String str_NoData = "";
				String testData = "";
				tsStatus = "Done";
				if (eventType == "SETTEXT") {
					String Cur_TestData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));
					log.info("TESTDATA" + Cur_TestData);
					str_NoData = Cur_TestData;
					if (String.valueOf(Cur_TestData).toUpperCase().equalsIgnoreCase("NODATA")) {
						Cur_TestData = "";
					} else {
						if (Cur_TestData.toUpperCase().startsWith("DYN_")) {
							Get_DynamicValue(Cur_TestData);
							testData = Cur_TestData;
							Cur_TestData = Dynamic_TestValue;
							tsStatus = "Done";
						} else if (str_Property == "ID") {
							driver.findElement(By.id(objectName)).sendKeys(Cur_TestData);
							testData = Cur_TestData;
							tsStatus = "Done";
						} else if (str_Property == "NAME") {
							driver.findElement(By.name(objectName)).sendKeys(Cur_TestData);
							testData = Cur_TestData;
							tsStatus = "Done";
						}
					}
				} else if (eventType == "CLICK") {

					if (str_Property == "ID") {
						driver.findElement(By.id(objectName)).click();
						tsStatus = "Done";
					} else if (str_Property == "NAME") {
						driver.findElement(By.name(objectName)).click();
						tsStatus = "Done";
					} else if (str_Property == "DYNAMIC_1") {
						log.info("check dynamic");
						WebElement element = driver.findElement(By.id(objectName));
						String Dyn_Data = element.getText();
						log.info("Get Dymaic Data " + Dyn_Data);
						log.info("Get Dymaic ID " + objectName);
						ActualTestDataValue = Dyn_Data;
						Func_UpdateDynamicValue(KeywordName, Dyn_Data);
						tsStatus = "Pass";
					}
				} else if (eventType == "TAB") {
					driver.findElement(By.name(objectName)).sendKeys(Keys.TAB);
					tsStatus = "Done";
				}
				sno++;
				result(KeywordName, testData, tsStatus, Cur_objectId, subIteration, eventType);
				ActualTestDataValue = "";
				Loggerupdator("Keyword Performed  :" + KeywordName + "\n Test Data :" + testData + "\n Status: "
						+ tsStatus + "\n eventType " + eventType, "Func_MainNew", 1, "");

			}

		} catch (Exception ex) {
			Loggerupdator("Keyword " + KeywordName + " is not performed", "Window_automation", 0, ex.toString());
			checkErrorTest(Cur_objectId, subIteration, eventType, KeywordName, ex.toString());
		}
	 }
	
	
	    /// ############################################################################
		/// FUNCTIONS FOR RUN THE SUB FLOW SCENARIOS
		/// ############################################################################

		public void fnInitiateSubFlow(String strFlowName) {
			try {
				// Set Flag Initiate Sub Flow (If Sub Flow Initiated Flag Set to -> 1 flow
				// completed Flag Set to -> 0)
				_ItsSubFlowTC = 1;

				// Variable Declarations for SubFlows
				String strTestCaseName = "";
				String strTestCaseID = "";
				String strTestScript = "";
				String strTestLibraryName = "";

				String Qry = "SELECT t1.Testcase_ID,t1.Subflow_Name,t2.testcasename,t2.testscript FROM tbl_Testcase_Subflow_Mapping t1,tbl_testcase t2 Where t1.Subflow_Name='"
						+ strFlowName + "' and t1.Testcase_ID=t2.testcaseid";
						
				JSONArray jsondata= RestApicall(Qry);	
				for (int i = 0; i <= jsondata.length() - 1; i++) {	
					JSONObject rs = jsondata.getJSONObject(i);
					
					strTestCaseName += rs.getString("testcasename");
					strTestCaseID += rs.getString("Testcase_ID");
					strTestScript += rs.getString("testscript");				
				}		

				// Assigning Retrieved data to Global variables.
				pubSubTestCaseName = strTestCaseName;
				pubSubTestCaseID = strTestCaseID;
				pubSubTestScript = strTestScript;
				List<String> pubSubBusinessKeywordsList = new ArrayList<>();

				// Generate the Test ApplicationLibrary Name
				strTestLibraryName = PubApplicationName + "_" + PubApplicationID + "_ApplicationLibrary";

				// Load Test Data and Test Descriptions for Sub Flows Test Cases
				funloadTestDataSubFlow();
				funloadTestStepDescSubFlow();

				// Extracting the Business Keywords from Test Script and add to List
				pubSubBusinessKeywordsList = funSubFlowScriptGenerate(pubSubTestScript);

				// Looping Business Keywords from a Array List
				for (String temp : pubSubBusinessKeywordsList) {
					String aClass = "SeleniumProject." + strTestLibraryName;
					String[] arrOfStr = temp.split("\\(");
					String aMethod = arrOfStr[0].trim();
					Class params[] = {};
					Object paramsObj[] = {};

					Class thisClass = Class.forName(aClass);
					Object iClass = thisClass.newInstance();

					// Method thisMethod = thisClass.getDeclaredMethod(aMethod, params);
					Method thisMethod = thisClass.getDeclaredMethod(aMethod, int.class);

					// Method gs1Method = thisClass.getMethod("publicSum",int.class,int.class);
					thisMethod.invoke(iClass, Integer.parseInt(arrOfStr[1]));

					System.out.println(temp);
				}

				// Set Flag De - Initiate Sub Flow
				_ItsSubFlowTC = 0;
			} catch (InstantiationException ex) {
				_ItsSubFlowTC = 0;
				System.err.println("Not able to create Instance of Class");
			} catch (IllegalAccessException ex) {
				System.err.println("Not able to access Class");
			} catch (ClassNotFoundException ex) {
				System.err.println("Not able to find Class");
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}

		}
		/// This function is used to Get the List of business keywords from business
		/// keywords.
		public List<String> funSubFlowScriptGenerate(String strScript) {
			// Split Strings and collect into array
			String[] arrOfStr = strScript.split("\n");
			// List to collect the Business Keywords
			List<String> myList = new ArrayList<>();
			try {
				// Looping array list and grab the Business Keywords (identified by k1. starts
				// with)
				for (String a : arrOfStr)

					if (a.trim().startsWith("kl.")) {
						myList.add(a.trim().replace("kl.", "").replace(");", ""));
					}
			} catch (Exception e) {
				System.out.println("Error: " + e);
			}
			return myList;
		}
		// Load Testdata for current testcase and iteration
		public void funloadTestDataSubFlow() {
			try {

				log.info("*******************************************************************");
				log.info("SubFlow Iteration " + pub_Cur_Iteration + " Started");
				log.info("*******************************************************************");

				// Get Test Data Values				
				String qryGetTestData = "SELECT * FROM tbl_IterationMapping WHERE testcaseid = "
						+ Integer.parseInt(pubSubTestCaseID)
						+ " AND iterationid = (SELECT IterationId FROM tbl_Iteration WHERE TestcaseID= "
						+ Integer.parseInt(pubSubTestCaseID) + " AND IterationNumber= "
						+ Integer.parseInt(pub_Cur_Iteration) + " AND TDEnvID = " + Integer.parseInt(pub_TDEnvID)
						+ "  AND ProductNameID = " + Integer.parseInt(ProductID) + " AND RiderCodeNameID = 0 )";
				
			JSONArray jsondata = RestApicall(qryGetTestData);
			_subFlowTestData = new HashMap<String, String>();
			for (int i = 0; i <= jsondata.length() - 1; i++) {
				JSONObject rs = jsondata.getJSONObject(i);
				String strObjectMap = rs.getString("ObjID") + "_" + rs.getString("SubIterationId");
				String strTestData = rs.getString("InputData");
				if (strTestData == null || strTestData == "") {

					_subFlowTestData.put(strObjectMap, "");
				} else {

					_subFlowTestData.put(strObjectMap, strTestData);
				}
			}					
			} catch (Exception e) {
				System.out.println("Error: " + e);
			} finally {

			}
		}
		// Get Description for Test steps
		public void funloadTestStepDescSubFlow() {
			try {
				// Get Values
				String qryGetdescData = "SELECT * FROM tbl_TestStepDescription WHERE testcaseid = "
						+ Integer.parseInt(pubSubTestCaseID) + "";
				JSONArray jsondata = RestApicall(qryGetdescData);
				_subFlowTestDescription = new HashMap<String, String>();
				for (int i = 0; i <= jsondata.length() - 1; i++) {
					JSONObject rs = jsondata.getJSONObject(i);
													
					String strObjectMap = rs.getString("ObjectID") + "_" + rs.getString("SubIteration");
					String strTestStepDesc = rs.getString("TestStep_Desc");

					if (strTestStepDesc == null || strTestStepDesc == "" || strTestStepDesc == "null") {

						_subFlowTestDescription.put(strObjectMap, "");
					} else {

						_subFlowTestDescription.put(strObjectMap, strTestStepDesc);
					}
				}		
			}
			catch (Exception e) {
				System.out.println("Error: " + e);
			}
		}
	// Execute the Test steps using Keyword property
	public void Func_MainNew(String Screen_ID, String objectName, String ObjectClass, String eventType,
			String Cur_objectId, int subIteration, String KeywordName, String str_Property) {
		try {

			switch (Pub_DefaultBrowserName.toUpperCase()) {
			case "IOS":
				IOS_automation(Screen_ID, objectName, ObjectClass, eventType, Cur_objectId, subIteration, KeywordName,
						str_Property);
				break;

			case "ANDROID":
				Android_automation(Screen_ID, objectName, ObjectClass, eventType, Cur_objectId, subIteration, KeywordName,
						str_Property);
				break;

			case "WINAPP":
				Window_automation(Screen_ID, objectName, ObjectClass, eventType, Cur_objectId, subIteration, KeywordName,
						str_Property);
				break;
				
			case "TERMINAL":
				Terminal_automation(Screen_ID, objectName, ObjectClass, eventType, Cur_objectId, subIteration, KeywordName,
						str_Property);
				break;

			default:
				Web_automation(Screen_ID, objectName, ObjectClass, eventType, Cur_objectId, subIteration, KeywordName,
						str_Property);
				break;
			}

		} catch (Exception ex) {
			Loggerupdator("Error Execution", "Func_MainNew", 0, ex.toString());
		}
	}

	private void WaitUntilElementPresent(String objectName, String str_Property, String pub_DefaultBrowserName) {
		
		try{
			
			
			if (pub_DefaultBrowserName.equalsIgnoreCase("Android")) {

				if (str_Property.equalsIgnoreCase("id")) {

					new WebDriverWait(AndroidDriver, 10)
							.until(ExpectedConditions.presenceOfElementLocated(By.id(objectName)));
				} else if (str_Property.equalsIgnoreCase("name")) {

					new WebDriverWait(AndroidDriver, 10)
							.until(ExpectedConditions.presenceOfElementLocated(By.name(objectName)));

				} else if (str_Property.equalsIgnoreCase("xpath")) {

					new WebDriverWait(AndroidDriver, 10)
							.until(ExpectedConditions.presenceOfElementLocated(By.xpath(objectName)));
				}

			} else if (pub_DefaultBrowserName.equalsIgnoreCase("IOS")) {

				if (str_Property.equalsIgnoreCase("id")) {
					new WebDriverWait(IOSdriver, 5)
							.until(ExpectedConditions.presenceOfElementLocated(By.id(objectName)));

				} else if (str_Property.equalsIgnoreCase("name")) {

					new WebDriverWait(IOSdriver, 5)
							.until(ExpectedConditions.presenceOfElementLocated(By.name(objectName)));

				} else if (str_Property.equalsIgnoreCase("xpath")) {

					new WebDriverWait(IOSdriver, 5)
							.until(ExpectedConditions.presenceOfElementLocated(By.xpath(objectName)));
				}

			} else if (pub_DefaultBrowserName.equalsIgnoreCase("Terminal")) {

				//

			} else if (!pub_DefaultBrowserName.equalsIgnoreCase("winapp")) {
							
				if (str_Property.equalsIgnoreCase("id")) {

					new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.id(objectName)));

				} else if (str_Property.equalsIgnoreCase("name")) {

					new WebDriverWait(driver, 10)
							.until(ExpectedConditions.visibilityOfElementLocated(By.name(objectName)));

				} else if (str_Property.equalsIgnoreCase("xpath")) {

					new WebDriverWait(driver, 10)
							.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(objectName)));
				}

			}

		} catch (Exception ex) {
			Loggerupdator("Could not locate element","WaitUntilElementPresent",0,ex.toString());

		}

	}
	
	public boolean waitForJStoLoad() {

	    WebDriverWait wait = new WebDriverWait(driver, 30);
	    // wait for Javascript to load
	    ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
	      @Override
	      public Boolean apply(WebDriver driver) {
              return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
	      }
	    };
	  return  wait.until(jsLoad);
	}

	private String generateXPATH(WebElement childElement, String current) {
		String childTag = childElement.getTagName();
		if (childTag.equals("html")) {
			return "/html[1]" + current;
		}
		WebElement parentElement = childElement.findElement(By.xpath(".."));
		List<WebElement> childrenElements = parentElement.findElements(By.xpath("*"));
		int count = 0;
		for (int i = 0; i < childrenElements.size(); i++) {
			WebElement childrenElement = childrenElements.get(i);
			String childrenElementTag = childrenElement.getTagName();
			if (childTag.equals(childrenElementTag)) {
				count++;
			}
			if (childElement.equals(childrenElement)) {
				return generateXPATH(parentElement, "/" + childTag + "[" + count + "]" + current);
			}
		}
		return null;
	}

	// If Test step is failed , move to next Iteration
	public void checkErrorTest(String Cur_objectId, int subIteration, String eventType, String KeywordName,
			String errMsg) {
		try {
			sno++;
			pub_getTestcaseStatus = "Failed";
			pub_getIterationStatus = "Failed";
			tsStatus = "Fail";
			TestcaseFinalStatus = "Fail";
			String testData=fnGetTestData(Cur_objectId,String.valueOf(subIteration));

			if (eventType == "CLICK") {
				testData = "";
			}
			if (eventType == "EXIST") {
				testData = "";
			}
			if (String.valueOf(testData) == "null") {
				testData = "";
			}
			tcStatus = "Fail";
			result(KeywordName, testData, tsStatus, Cur_objectId, subIteration, eventType);		
			if (IterationCount == ArrIterations.length) {
				System.out.println("ITERATION Completed");
				resultfinal("error");

				if ((Pub_DefaultBrowserName.equals("IOS"))) {
					IOSdriver.quit();
					IOSdriver = null;
					update_device_status(0, DeviceID);
				} else if (Pub_DefaultBrowserName.equalsIgnoreCase("Android")) {
					AndroidDriver.quit();
					AndroidDriver = null;
					update_device_status(0, DeviceID);
				} else {
					driver.close();
					driver.quit();
					driver = null;
				}
				Check_BackgroundWorker();
				System.exit(0);

			} else if (errMsg.contains("Unable to find element on closed window") || errMsg.contains("not reachable")
					|| errMsg.contains("Failed to decode response from marionette")
					|| errMsg.contains("Unable to find element on closed window")
					|| errMsg.contains("Tried to run command without establishing a connection")
					|| errMsg.contains("Window is closed")) {
				Loggerupdator("Unfortunately Browser is Closed...","checkErrorTest",0,"");
				resultfinal("error");
				driver.close();
				driver.quit();
				driver = null;
				Check_BackgroundWorker();
				System.exit(0);
			} else {
				Loggerupdator("Starting Next Iteration...","checkErrorTest",1,"");
			}

		} catch (Exception ex) {
			Loggerupdator("checkErrorTest Failed","checkErrorTest",0,ex.toString());
			Check_BackgroundWorker();
			System.exit(0);
		}
	}

	// Function to select the day of month in the date picker.
	public void SelectDayFromMultiDateCalendar(String day) throws InterruptedException {

		// We are using a special XPath style to select the day of current
		// month.
		// It will ignore the previous or next month day and pick the correct
		// one.
		By calendarXpath = By.xpath("//td[not(contains(@class,'ui-datepicker-other-month'))]/a[text()='" + day + "']");
		driver.findElement(calendarXpath).click();

		// Intentional pause for 2 seconds.
		Thread.sleep(2000);
	}

	public void createResultFolder() {
		try {
		   tcResultFolder = pubTestCaseName;
		   testCaseResultPath = ResultCyclepath + "\\\\" + tcResultFolder + "\\\\" + Pub_ExecutionRequestId + "\\\\";
					
			/**********************************************************************************************************************/
			String qry1 = "SELECT ID FROM tbl_browsers WHERE Browser_Type ='" + BrowserTypeResult + "' and Del_Flag=1";
			JSONArray jsondata= RestApicall(qry1);		
			if (jsondata.length() > 0) {		
				JSONObject rs1 = jsondata.getJSONObject(0);		
				int BType = rs1.getInt("ID");
				BrowserType = new Integer(BType).toString();
			}
			/**********************************************************************************************************************/	
			testCaseResultPath = testCaseResultPath + BrowserTypeResult + "\\\\";
			
			Loggerupdator("Result Folder : "+testCaseResultPath,"createResultFolder",1,"");			
		} catch (Exception e) {
			Loggerupdator("Could not get Browser Type.","createResultFolder",0,e.toString());			
		}
	}

	public void result(String KeywordName, String testData2, String status, String ObjectID, int SubIteration,
			String eventType) {
		byte[] data = null;
		String tsScreenshotPath="";
		File scrFile=null;
		String screenshotFolderPath = testCaseResultPath + "screenshots\\\\";
		try {
			if (status.toLowerCase().equals("fail")) {
				pub_getTestcaseStatus = "Failed";
				pub_getIterationStatus = "Failed";
				tsStatus = "Fail";
				TestcaseFinalStatus = "Fail";
				tcStatus = "Fail";
			}
			if (ObjectID == "") {
				String qry = "SELECT ObjID FROM tbl_Objects WHERE KeywordName ='" + KeywordName + "' and ApplicationID="
						+ PubApplicationID + "";		
				JSONArray jsondata= RestApicall(qry);					
				if (jsondata.length() > 0) {
					JSONObject rs = jsondata.getJSONObject(0);
					int objId = rs.getInt("ObjID");				
					ObjectID = String.valueOf(objId);			
					
				}
			}		
	/***************************************************************************************************************	*/				
		                               /** Image Processing ****/			
	/***************************************************************************************************************	*/	
		//	boolean screenshotflag=true;
			boolean screenshotflag=	checkscreenshotflag(eventType,status);
			
			if(screenshotflag) {				
				tsScreenshotPath = screenshotFolderPath + pub_Cur_Iteration + "_" + (sno) + "_" + ObjectID + ".jpg";
				if (!eventType.equals("FULLSCREENSHOT") && (!eventType.equals("Alert"))) {
					if ((Pub_DefaultBrowserName.equals("IOS"))) {
						data = ((TakesScreenshot) IOSdriver).getScreenshotAs(OutputType.BYTES);
						scrFile = File.createTempFile("tmp", ".jpg");
					} else if ((Pub_DefaultBrowserName.equals("Android"))) {

						data = ((TakesScreenshot) AndroidDriver).getScreenshotAs(OutputType.BYTES);
						scrFile = File.createTempFile("tmp", ".jpg");
					} else if ((Pub_DefaultBrowserName.equals("Terminal"))) {
				        BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));			
						scrFile = File.createTempFile("tmp", ".jpg");		
					    ByteArrayOutputStream bytes= new ByteArrayOutputStream();
						ImageIO.write(image, "jpg", bytes);
						data = bytes.toByteArray();
					} 			
					else {												
						data = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
						scrFile = File.createTempFile("tmp", ".jpg");    										
						/**** BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));			
						scrFile = File.createTempFile("tmp", ".jpg");	****/ 	
					   // ByteArrayOutputStream bytes= new ByteArrayOutputStream();
						//ImageIO.write(image, "png", bytes);
						//data = bytes.toByteArray();
						
					}
				} else if (eventType.equalsIgnoreCase("Alert")) {
					Robot robotClassObject = new Robot();
					Rectangle screenSize = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
					BufferedImage tmp = robotClassObject.createScreenCapture(screenSize);
					  scrFile = File.createTempFile("tmp", ".jpg");
			          ByteArrayOutputStream bytes= new ByteArrayOutputStream();
					  ImageIO.write(tmp, "jpg", bytes);
					  data = bytes.toByteArray();
				} else {
					Screenshot screenshot;
					screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000))
							.takeScreenshot(driver);
					  scrFile = File.createTempFile("tmp", ".jpg");			
					  ByteArrayOutputStream bytes= new ByteArrayOutputStream();
					  ImageIO.write(screenshot.getImage(), "jpg", bytes);
					  data = bytes.toByteArray();
				}
			}
			
			/** Check Dynamic flag ***/
			int dyn_flg = 0;
			if (Pub_dynamicValue != "") {
				dyn_flg = 1;
			}
			/** Background Worker ****/
			resultapi(KeywordName, testData2, status, tsScreenshotPath, ObjectID, SubIteration, eventType, scrFile,
					data,ActualTestDataValue,dyn_flg,screenshotflag);
		} catch (Exception e) {
			Loggerupdator("Could not get Result Keyword Name: "+ KeywordName,"result",0,e.toString());			
		}
	}

	private boolean checkscreenshotflag(String eventType, String status) {

		try {

			if (Env_ScreenShotFlag == 0) {			
    			return false;		
			} else if (Env_ScreenShotFlag == 1) {
				return true;
			} else if (Env_ScreenShotFlag == 2) {

				if (status.equalsIgnoreCase("Fail")) {
					return true;
				}
			} else {
				if (eventType.equalsIgnoreCase("Verify")) {
					return true;
				}
			}
		} catch (Exception ex) {
			Loggerupdator("Error checkscreenshotflag ", "checkscreenshotflag", 0, ex.toString());
		}		
		return false;
	}

	public void resultapi(String keywordName, String testData2, String status, String tsScreenshotPath, String objectID, int subIteration, String eventType, File scrFile2, byte[] imgdata, String actualTestDataValue2, int dyn_flg, boolean screenshotflag)
	{		
		try{
			Loggerupdator("screen captured and saving... ----Performed KEYWORD: "+keywordName,"resultapi",2,"");			

			/** Background Worker stream file****/
			  Callable<Integer> resulttask = () -> {
		            try {
		            	            	
		            	/** Image Compression ****/
		    			BufferedImage bufferedImage = ImageIO.read(new ByteArrayInputStream(pngBytesToJpgBytes(imgdata)));
		    			ImageIO.write(bufferedImage, "JPG", scrFile2);	
		            	
		    			/** Rest Api ****/
		    			Response response = RestAssured.given()
								.baseUri(Apiservice)
								.basePath("FrameworkAPI/UploadFile")
								.queryParam("Screenshotpath",tsScreenshotPath)
								.multiPart("Image", scrFile2, "application/octet-stream")
								.post(); 

		    			if(response.statusCode()==200){
		    				
		    				Loggerupdator("Captured screen saved through Quantum API----Performed KEYWORD: "+keywordName,"resultapi",2,"");			

		    			}else{
		    				Loggerupdator("Failed to save captured screen ----Performed KEYWORD: "+keywordName,"resultapi",0,response.asString());			

		    			}	    			
		    			/** Remove temp file ****/		    		  	 
		    		  	scrFile2.delete();		    		  	 
		    		  	 return 1;
		            }
		            catch (Exception e) {
		    			Loggerupdator("Could not connect result api to quantum: ","resultapi",0,e.toString());			
		                throw new IllegalStateException("task interrupted", e);
		            }
		        };				        
				/** Background Worker ExecutionSteps****/
		        Callable<Integer> ExecutionStepsDB = () -> {
		        	
				try {

					String testData = "";
					String Cur_TestStepDesc = "";

					if (!testData2.equalsIgnoreCase("NODATA")) {
						testData = testData2;
					}
					String ExpectedData = "";
					if (status == "Pass" || eventType.equalsIgnoreCase("verify")) {
						ExpectedData = testData;
						testData = "";
					}

					if (_ItsSubFlowTC == 1) {

						Cur_TestStepDesc = _subFlowTestDescription.get(objectID + "_" + String.valueOf(subIteration));
						if (String.valueOf(Cur_TestStepDesc) == "null") {
							Cur_TestStepDesc = "";
						}
					} else if (_ItsRiderFlowTC == 1) {

						Cur_TestStepDesc = _RiderTestStepDesc.get(objectID + "_" + String.valueOf(subIteration));
						if (String.valueOf(Cur_TestStepDesc) == "null") {
							Cur_TestStepDesc = "";
						}

					} else {
						Cur_TestStepDesc = TestStepDesc.get(objectID + "_" + String.valueOf(subIteration));

						if (String.valueOf(Cur_TestStepDesc) == "null") {
							Cur_TestStepDesc = "";
						}
					}

					Date dNow = new Date();
					SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					String Curr_Time = String.valueOf(ft.format(dNow));
					ExecutionStepsInDB(keywordName, testData, ExpectedData, actualTestDataValue2, status,
							tsScreenshotPath, objectID, subIteration, eventType, Curr_Time, Cur_TestStepDesc,
							screenshotflag,dyn_flg);
					Loggerupdator("Keyword details Inserted to DB------ Performed KEYWORD: " + keywordName, "resultapi",
							2, "");

				} catch (Exception ex) {
					Loggerupdator("Could not connect result api to quantum: ", "resultapi", 0, ex.toString());
					System.out.println(ex);
					return 0;
				}       			  	        	
		        	return 1;
		        };		        
		        /** DB Backwround Worker ***/
		        ExecutorService DBexecutor = Executors.newFixedThreadPool(1);
		        DBWorker = DBexecutor.submit(ExecutionStepsDB);
		        DBexecutor.shutdown();
		      
		        /** Result File Backwround Worker ***/	        
			if (screenshotflag) {
				ExecutorService executor = Executors.newFixedThreadPool(1);
				ResultWorker = executor.submit(resulttask);
				executor.shutdown();
			}
			
		/** Remove unnecessary memory ***/
		  	System.gc();

		}catch(Exception ex){
			Loggerupdator("Could not connect result api to quantum: ","resultapi",0,ex.toString());			
		}
	}	
	private static byte[] pngBytesToJpgBytes(byte[] pngBytes) throws IOException {
        //create InputStream for ImageIO using png byte[]
        ByteArrayInputStream bais = new ByteArrayInputStream(pngBytes);
        //read png bytes as an image
        BufferedImage bufferedImage = ImageIO.read(bais);

        BufferedImage newBufferedImage = new BufferedImage(bufferedImage.getWidth(),
                bufferedImage.getHeight(),
                BufferedImage.TYPE_INT_RGB);
        newBufferedImage.createGraphics().drawImage(bufferedImage, 0, 0, Color.WHITE, null);

        //create OutputStream to write prepaired jpg bytes
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        //write image as jpg bytes
        ImageIO.write(newBufferedImage, "JPG", baos);
        //convert OutputStream to a byte[]
        return baos.toByteArray();
    }
	// Complete the Current excution and overall result in Html file
	public void resultfinal(String executionStatus) {
		try {
			

         	if (sno == 0) {
				writeIterationHTML("");
			}			
			Loggerupdator("Iteration " + pub_Cur_Iteration + " Completed","resultfinal",1,"");	
			if (ArrIterations.length == IterationCount && executionStatus == "complete") {
				resultIterationfinal();
			} else if (executionStatus == "error") {			
				resultIterationfinal();
			}
		} catch (Exception ex) {
			Loggerupdator("Result final Iteration UPDATION failed: Iteration: "+pub_Cur_Iteration,"resultfinal",0,ex.toString());			
			
		} finally {

			if ((Pub_DefaultBrowserName.equals("IOS")) ||(Pub_DefaultBrowserName.equals("Android"))) {
				update_device_status(0, DeviceID); 
			}			
		}
	}
	
	public void Check_BackgroundWorker(){
		
		try {
			boolean status = true;
			System.out.println(" Result is updating.........................");
			while (status) {

				if (ResultWorker != null) {
					if (ResultWorker.isDone() && (DBWorker.isDone())) {
						status = false;
						System.out.println("========= Result is Updated... =========");
					} else {
						Thread.sleep(1000);
					}
				} else {
					if ((DBWorker.isDone())) {
						status = false;
						System.out.println("========= Result is Updated... =========");
					} else {
						Thread.sleep(1000);
					}
				}
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	// Complete the Current Testcase Execution and overall result in html file
	public void resultIterationfinal() {
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(new Date());
			java.sql.Date dt = new java.sql.Date(calendar.getTimeInMillis());
			java.sql.Time sqlTime = new java.sql.Time(calendar.getTime().getTime());
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			date = simpleDateFormat.parse(dt.toString() + " " + sqlTime.toString());
			timeStamp = new java.sql.Timestamp(date.getTime());

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date1 = new Date();
			System.out.println(dateFormat.format(date1));
					
			/*************************************************************************************/
			String strQuery = "Update TBL_EXECUTIONRESUTLS set TESTCASESTATUS = '" + pub_getTestcaseStatus
					+ "' ,TestcaseEndTime='" + dateFormat.format(date1) + "' , IterationNumber = " + pub_Cur_Iteration
					+ " where ID = " + Env_TestcaseExecutionID + "";
			
			RestApicall(strQuery);
			
			/*************************************************************************************/

			String sqlrun1 = " SELECT TestcaseStartTime,TestcaseEndTime FROM TBL_EXECUTIONRESUTLS where ID = "
					+ Env_TestcaseExecutionID + "";
			
			JSONArray jsondata= RestApicall(sqlrun1);
			for (int i = 0; i <= jsondata.length() - 1; i++) {
				
				JSONObject rs1 = jsondata.getJSONObject(i);
				
				String d11d = rs1.getString("TestcaseStartTime").replaceAll("T", " ");
				String d21d = rs1.getString("TestcaseEndTime").replaceAll("T", " ");
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date d1 = null;
				Date d2 = null;
				d1 = format.parse(d11d);
				d2 = format.parse(d21d);

				// in milliseconds
				long diff = d2.getTime() - d1.getTime();
				long diffSeconds = diff / 1000 % 60;
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffHours = diff / (60 * 60 * 1000) % 24;
				long diffDays = diff / (24 * 60 * 60 * 1000);

				String timeDuration = diffHours + ":" + diffMinutes + ":" + diffSeconds;
				/*************************************************************************************/
				strQuery = "Update TBL_EXECUTIONRESUTLS set TestcaseDuration='" + timeDuration + "' where ID = "
						+ Env_TestcaseExecutionID + "";
				
				 RestApicall(strQuery);
				 /*************************************************************************************/
				strQuery = "Update TBL_CYCLEMAPPING set TESTCASERESULTS = '" + pub_getTestcaseStatus
						+ "' where  CYCLEID = " + pub_CycleId + " and TESTCASEID = " + Integer.parseInt(pubTestCaseID)
						+ "";				
				 RestApicall(strQuery);
				 /*************************************************************************************/
				fnCrossBrowserResults();
				Loggerupdator("Testcase Execution Completed","resultIterationfinal",1,"");			
			}				
		} catch (Exception ex) {
			Loggerupdator("Result Iteration final status updation failed..","resultIterationfinal",0,ex.toString());			
		} 
	}
	public void writeIterationHTML(String CurIterationDet) throws IOException {
		try {

			if (sno == 0 && IterationCount == 1) {
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(new Date());
				java.sql.Date dt = new java.sql.Date(calendar.getTimeInMillis());
				java.sql.Time sqlTime = new java.sql.Time(calendar.getTime().getTime());
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				date = simpleDateFormat.parse(dt.toString() + " " + sqlTime.toString());
				timeStamp = new java.sql.Timestamp(date.getTime());

				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date1 = new Date();

				String TestResultPath = "";

				/*String strQuery = "UPDATE tbl_ExecutionResutls SET [TestcaseStatus] ='Started',[TestcaseStartTime] = '"
						+ dateFormat.format(date1) + "' ,[TestcaseResultFileName] = '" + TestResultPath
						+ "', [BrowserID] = " + BrowserType + " , [ProductID] = " + ProductID + " , [Env_ID] = "
						+ pub_Env_ID + " WHERE [ApplicationID] = " + PubApplicationID + " and [TestcaseID] = "
						+ Integer.parseInt(pubTestCaseID) + " and [IterationNumber] = " + pub_Cur_Iteration
						+ " and [ReleaseID] = " + pub_ReleaseId + " and [CycleID] = " + pub_CycleId
						+ " and [TestSetID] = " + pub_testsets + " and [UserID] = " + pub_UserID
						+ " and [Exe_Master_ID] = " + Pub_ExecutionRequestId;*/
				
				String strQuery = "UPDATE tbl_ExecutionResutls SET [TestcaseStatus] ='Started',[TestcaseStartTime] = '"
						+ dateFormat.format(date1) + "' ,[TestcaseResultFileName] = '" + TestResultPath
						+ "', [BrowserID] = " + BrowserType + ", [ScreenshotFlag] = " + Env_ScreenShotFlag +" , [ProductID] = " + ProductID + " , [Env_ID] = "
						+ pub_Env_ID + " WHERE [ApplicationID] = " + PubApplicationID + " and [TestcaseID] = "
						+ Integer.parseInt(pubTestCaseID) + " and [IterationNumber] = " + pub_Cur_Iteration
						+ " and [ReleaseID] = " + pub_ReleaseId + " and [CycleID] = " + pub_CycleId
						+ " and [TestSetID] = " + pub_testsets + " and [UserID] = " + pub_UserID 
						+ " and [Exe_Master_ID] = " + Pub_ExecutionRequestId;
				RestApicall(strQuery);
				/*************************************************************************************/

				strQuery = "select ISNULL(max(ID),0) from tbl_ExecutionResutls  where [ApplicationID] = "
						+ PubApplicationID + " and ReleaseID = " + pub_ReleaseId + " and CycleID = " + pub_CycleId
						+ " and TestsetID = " + pub_testsets + " and TestcaseID = " + Integer.parseInt(pubTestCaseID)
						+ " and [IterationNumber] = " + pub_Cur_Iteration + " and [UserID] = " + pub_UserID
						+ " and [Exe_Master_ID] = " + Pub_ExecutionRequestId;

				JSONArray rs = RestApicall(strQuery);
				if (rs.length() > 0) {
					JSONObject object = rs.getJSONObject(0);
					Env_TestcaseExecutionID = object.getInt("Column1");
				}
				/*************************************************************************************/
				strQuery = "Update TBL_CYCLEMAPPING set TESTCASERESULTS = 'Failed' where  CYCLEID = '" + pub_CycleId
						+ "' and TESTCASEID = '" + pubTestCaseID + "'";

				RestApicall(strQuery);

				/*************************************************************************************/
			}
			Loggerupdator("Iteration "+pub_Cur_Iteration+ "Main file completed","writeIterationHTML",1,"");			
		}
		catch (Exception e) {
			Loggerupdator("writeIterationHTML DB Status Updation failed..","writeIterationHTML",0,e.toString());			
		} finally {
			if (IterationOutput != null) {
				IterationOutput.close();
				IterationOutputNew.close();
			}
		}
	}

	// Update Browser execution result after testcase execution completed
	public void fnCrossBrowserResults() {
		try {
			int BrowseStatus = 0;
			if (pub_getTestcaseStatus.contains("Passed")) {
				BrowseStatus = 1;
			} else {
				BrowseStatus = 2;
			}
			String qry = "SELECT TestcaseID FROM tbl_CrossBrowserResults WHERE TestcaseID ="
					+ Integer.parseInt(pubTestCaseID) + " and TestsetID=" + pub_testsets + " and Browser_Type="
					+ Integer.parseInt(BrowserType) + "";				
			JSONArray jsondata = RestApicall(qry);		
			if (jsondata.length() > 0) {
				JSONObject rs = jsondata.getJSONObject(0);
				String strQuery = "Update tbl_CrossBrowserResults set Browser_Status=" + BrowseStatus
						+ " Where TestcaseID =" + Integer.parseInt(pubTestCaseID) + " and TestSetID = " + pub_testsets
						+ " and Browser_Type= " + Integer.parseInt(BrowserType) + "";				
				 RestApicall(strQuery);		
			} else {
				String strQuery = "Insert into tbl_CrossBrowserResults (TestcaseID,TestSetID,Browser_Type,Browser_Status) values ("
						+ Integer.parseInt(pubTestCaseID) + "," + pub_testsets + "," + Integer.parseInt(BrowserType)
						+ "," + BrowseStatus + ")";
				 RestApicall(strQuery);		
			}
		} catch (Exception ex) {
			Loggerupdator("fnCrossBrowserResults","fnCrossBrowserResults",0,ex.toString());			
		}
	}

	// set wait time for execution process
	public void SetWaitTime(int WaitSeconds) {
		try {
			driver.manage().timeouts().implicitlyWait(WaitSeconds, TimeUnit.SECONDS);
		} catch (Exception ex) {

		}
	}

	// Scroll down function for browser window
	public void scrollDown() {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,250)", "");
		} catch (Exception ex) {

		}
	}

	public void scrollUp() {
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollBy(0,-250)", "");
		} catch (Exception ex) {

		}
	}

	// To handle unexpected alert on page load.
	public void Alert_Dismiss() {
		try {
			driver.switchTo().alert().dismiss();
		} catch (Exception e) {
			System.out.println("unexpected alert not present");
		}
	}

	// get the Dynamic value by dynamic keyword name
	public void Get_DynamicValue(String dyn_Key) {
		try {
			Pub_dynamicValue = "";
			String interQuery = "";

			if (!ProductID.equals("0")) {

				interQuery = "select InterlinkTestcaseName,InterLinkIterationNumber from tbl_InterlinkTestcaseMappingforProduct where TestcaseID = '"
						+ pubTestCaseID + "' and IterationNumber = '" + pub_Cur_Iteration + "' and KeywordName = '"
						+ dyn_Key + "'  and ProductID = '" + ProductID + "'";

				JSONArray jsondata = RestApicall(interQuery);
				
				String strQuery = "";
				if (jsondata.length() > 0) {
					JSONObject rs1 = jsondata.getJSONObject(0);
					String interTcName = rs1.getString("InterlinkTestcaseName");

					int interIterationNum = rs1.getInt("InterLinkIterationNumber");

					strQuery = "Select COL_DYNAMIC_VALUE from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_TESTCASENAME = '"
							+ interTcName + "' and COL_DYNAMIC_VARIABLE = '" + dyn_Key + "' and COL_ITERATION = '"
							+ interIterationNum + "' and col_TDEnvID = '" + pub_TDEnvID + "' and COL_USER = '"
							+ pub_UserID + "'";

				} else {
					strQuery = "Select COL_DYNAMIC_VALUE from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_TESTCASENAME = '"
							+ pubTestCaseName + "' and COL_DYNAMIC_VARIABLE = '" + dyn_Key + "' and COL_ITERATION = '"
							+ pub_Cur_Iteration + "' and col_TDEnvID = '" + pub_TDEnvID + "' and COL_USER = '"
							+ pub_UserID + "'";
				}

				if (jsondata.length() == 0) {
					strQuery = "Select COL_DYNAMIC_VALUE from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_TESTCASENAME = '"
							+ pubTestCaseName + "' and COL_DYNAMIC_VARIABLE = '" + dyn_Key + "' and COL_ITERATION = '"
							+ pub_Cur_Iteration + "' and col_TDEnvID = '" + pub_TDEnvID + "' and COL_USER = '"
							+ pub_UserID + "'";
				}

				JSONArray rs12 = RestApicall(strQuery);					
				if (rs12.length() > 0) {
					JSONObject rs = rs12.getJSONObject(0);
					Dynamic_TestValue = rs.getString("COL_DYNAMIC_VALUE");
					log.info("Dyn Value" + Dynamic_TestValue);
				} else {
					Dynamic_TestValue = "";
				}
				Pub_dynamicValue = Dynamic_TestValue;

			} else {
				interQuery = "select InterlinkTestcaseName from tbl_IterlinkTestcaseMapping where TestcaseID = '"
						+ pubTestCaseID + "' and IterationNumber = '" + pub_Cur_Iteration + "' and KeywordName = '"
						+ dyn_Key + "'";
				
				JSONArray jsondata = RestApicall(interQuery);
				
				String strQuery = "";
				if (jsondata.length() > 0) {
					JSONObject rs1 = jsondata.getJSONObject(0);
					String interTcName = rs1.getString("InterlinkTestcaseName");

					strQuery = "Select COL_DYNAMIC_VALUE from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_TESTCASENAME = '"
							+ interTcName + "' and COL_DYNAMIC_VARIABLE = '" + dyn_Key + "' and COL_ITERATION = '"
							+ pub_Cur_Iteration + "' and col_TDEnvID = '" + pub_TDEnvID + "' and COL_USER = '"
							+ pub_UserID + "'";

				} else {
					strQuery = "Select COL_DYNAMIC_VALUE from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_TESTCASENAME = '"
							+ pubTestCaseName + "' and COL_DYNAMIC_VARIABLE = '" + dyn_Key + "' and COL_ITERATION = '"
							+ pub_Cur_Iteration + "' and col_TDEnvID = '" + pub_TDEnvID + "' and COL_USER = '"
							+ pub_UserID + "'";
				}

				if (jsondata.length()  == 0) {
					strQuery = "Select COL_DYNAMIC_VALUE from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_TESTCASENAME = '"
							+ pubTestCaseName + "' and COL_DYNAMIC_VARIABLE = '" + dyn_Key + "' and COL_ITERATION = '"
							+ pub_Cur_Iteration + "' and col_TDEnvID = '" + pub_TDEnvID + "' and COL_USER = '"
							+ pub_UserID + "'";
				}

				JSONArray rs12 = RestApicall(strQuery);			
				if (rs12.length() > 0) {
					JSONObject rs = rs12.getJSONObject(0);	
					Dynamic_TestValue = rs.getString("COL_DYNAMIC_VALUE");
					log.info("Dyn Value" + Dynamic_TestValue);
				} else {
					Dynamic_TestValue = "";
				}
				Pub_dynamicValue = Dynamic_TestValue;
			}
			
			Loggerupdator("Dynamic Value for : "+dyn_Key+" : "+Pub_dynamicValue,"Get_DynamicValue",2,"");			
		} catch (Exception ex) {
			Loggerupdator("Could not get DynKeyword value : "+dyn_Key,"Get_DynamicValue",0,ex.toString());			
		}
	}

	// Update the Dynamic testdata value to Temp Table
	public void Func_UpdateDynamicValue(String dyn_Key, String dyn_TestData) {
		try {
			/**************************************************************************/
			String strQuery = "Select COL_ITERATION from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_TESTCASENAME = '"
					+ pubTestCaseName + "' and COL_DYNAMIC_VARIABLE = '" + dyn_Key + "' and COL_USER = '" + pub_UserID
					+ "' and COL_ITERATION = '" + pub_Cur_Iteration + "' and COL_TDEnvID = '" + pub_TDEnvID + "'";
			JSONArray rs12 = RestApicall(strQuery);			
			if (rs12.length() > 0) {
				JSONObject rs = rs12.getJSONObject(0);
				/**************************************************************************/
				strQuery = "Update TBL_DYNAMICDATA set COL_DYNAMIC_VALUE = '" + dyn_TestData
						+ "' where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_TESTCASENAME = '" + pubTestCaseName
						+ "' and COL_DYNAMIC_VARIABLE = '" + dyn_Key + "' and COL_USER = '" + pub_UserID
						+ "' and COL_ITERATION = '" + pub_Cur_Iteration + "' and COL_TDEnvID = '" + pub_TDEnvID + "'";
				RestApicall(strQuery);
				/**************************************************************************/
			} else {
				/**************************************************************************/
				strQuery = "insert into TBL_DYNAMICDATA (COL_VARIABLETYPE,COL_TESTCASENAME,COL_DYNAMIC_VARIABLE,COL_DYNAMIC_VALUE,COL_USER,COL_ITERATION,COL_TDEnvID) values ('DYNAMICDATA','"
						+ pubTestCaseName + "','" + dyn_Key + "','" + dyn_TestData + "','" + pub_UserID + "','"
						+ pub_Cur_Iteration + "','" + pub_TDEnvID + "')";
				RestApicall(strQuery);
				/**************************************************************************/
			}
			
			Loggerupdator("Dymaic Value Updation : "+dyn_Key,"Func_UpdateDynamicValue",2,"");			
		} catch (Exception ex) {
			Loggerupdator("Could not update DynKeyword value : "+dyn_Key,"Func_UpdateDynamicValue",0,ex.toString());			

		}
	}

	// Find the values in HTML Table
	public static void FindTableContent(int tableValueIdx, int tableRadioIdx, String TableValue) {
		try {
			List<WebElement> table_count = driver.findElements(By.tagName("table"));
			int tables_count = table_count.size();
			// To locate rows of table.
			for (int table = 1; table < tables_count; table++) {
				List<WebElement> rows_table = table_count.get(table).findElements(By.tagName("tr"));
				// To calculate no of rows In table.
				int rows_count = rows_table.size();

				int check_radio = 0;
				for (int row = 0; row < rows_count; row++) {

					List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
					int columns_count = Columns_row.size();
					if (tableValueIdx <= columns_count) {
						System.out.println("Number of cells In Row " + row + " are " + columns_count);
						String celltext = Columns_row.get(tableValueIdx).getText().toString();
						if (celltext.equals(TableValue)) {
							Columns_row.get(tableRadioIdx).findElement(By.tagName("input")).click();
							check_radio = 1;
							break;
						}
					}
				}
				if (check_radio == 1) {
					break;
				}
			}
		} catch (Exception ex) {

		}
	}
	public void Close_TestExecution() {
		try {
			
			Check_BackgroundWorker();
			
			/**************************************************************************/
			String strQuery1 = "Update tbl_CurrentExecution set Status='" + pub_getTestcaseStatus
					+ "' where TestcaseID=" + Integer.parseInt(pubTestCaseID) + " and UserID=" + pub_UserID
					+ " and cycleID=" + pub_CycleId + "";
			
			RestApicall(strQuery1);
			/**************************************************************************/
		
			if ((Pub_DefaultBrowserName.equals("IOS"))) {						
				IOSdriver.quit();
				IOSdriver = null;
				update_device_status(0, DeviceID);
			}else if (Pub_DefaultBrowserName.equalsIgnoreCase("Android")) {						
				AndroidDriver.quit();
				AndroidDriver = null;	
				update_device_status(0, DeviceID);
			}else if (Pub_DefaultBrowserName.equalsIgnoreCase("Terminal")) {					
				Runtime rt = Runtime.getRuntime();
				rt.exec("taskkill /F /IM cwserv5.exe");			
			}else {			
				driver.close();
				driver.quit();
				driver = null;
			}		
		} catch (Exception ex) {
			Loggerupdator("Could not kill Driver Connection","Close_TestExecution",0,ex.toString());			
		}
	}

	public static void selectTableFirstRow(String TableID, int StartRow, int ColumnIDX) {

		try {

			Thread.sleep(3000);
			String TableValue1 = "";
			// "scrollGridTableNew1"

			log.info("Table123  " + TableValue1);
			WebElement e1 = driver.findElement(By.id(TableID));

			List<WebElement> rows_tbody = e1.findElements(By.tagName("tbody"));
			List<WebElement> rows_table = rows_tbody.get(0).findElements(By.tagName("tr"));
			// To calculate no of rows In table.
			int rows_count = rows_table.size();
			log.info("Row Size  " + rows_count);

			for (int row = StartRow; row < rows_count; row++) {
				List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
				int columns_count = Columns_row.size();

				if (row == StartRow) {
					Columns_row.get(ColumnIDX).findElement(By.tagName("input")).click();
					break;
				}

			}

		} catch (Exception ex) {
			log.info("Table error  " + ex.getMessage());
		}

	}

	// Find the values in HTML Table
	public static void Table_UnselectCheckbox(String TableID, int StartRow, int ColumnIDX) {

		try {

			Thread.sleep(3000);
			String TableValue1 = "";
			WebElement e1 = driver.findElement(By.id(TableID));

			List<WebElement> rows_tbody = e1.findElements(By.tagName("tbody"));
			List<WebElement> rows_table = rows_tbody.get(0).findElements(By.tagName("tr"));
			// To calculate no of rows In table.
			int rows_count = rows_table.size();
			log.info("Row Size  " + rows_count);

			for (int row = StartRow; row < rows_count; row++) {

				List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
				WebElement e2 = Columns_row.get(ColumnIDX).findElement(By.tagName("input"));
				if (e2.isSelected()) {
					e2.click();

				}
				if (row == StartRow) {
					e2.click();

				}
			}

		} catch (Exception ex) {
			log.info("Table error  " + ex.getMessage());
		}

	}

	// Find the values in HTML Table
	public void Table_SelectRadio_dynamicNo(String TableID, int StartRow, int ColumnIDX, String Dynamic_Keyword,
			int Dynamic_ColumnIndx, String Dynamic_Field) {

		try {
			ActualTestDataValue = "";
			Thread.sleep(3000);
			String Dynamic_TestValue = "";
			String strQuery = "";
			if (Dynamic_Keyword.toUpperCase().startsWith("DYN_")) {
				strQuery = "Select COL_DYNAMIC_VALUE from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_DYNAMIC_VARIABLE = '"
						+ Dynamic_Keyword + "' and COL_ITERATION = '" + pub_Cur_Iteration + "'";
							
				JSONArray jsondata= RestApicall(strQuery);		
				if (jsondata.length() > 0) {
					JSONObject rs = jsondata.getJSONObject(0);	
					Dynamic_TestValue = rs.getString("COL_DYNAMIC_VALUE");
				} else {
					Dynamic_TestValue = "";
				}
						
			} else {
				String qryGetTestData = "SELECT objid from tbl_objects where Applicationid="
						+ Integer.parseInt(PubApplicationID) + " and keywordname='" + Dynamic_Keyword + "'";
				log.info(qryGetTestData);
			
				JSONArray jsondata= RestApicall(qryGetTestData);			
				for (int i = 0; i <= jsondata.length() - 1; i++) {			
					JSONObject rs = jsondata.getJSONObject(i);
					
					strQuery = "SELECT * FROM tbl_IterationMapping WHERE objid="
							+ Integer.parseInt(rs.getString("ObjID")) + " and testcaseid = "
							+ Integer.parseInt(pubTestCaseID)
							+ " AND iterationid = (SELECT IterationId FROM tbl_Iteration WHERE TestcaseID= "
							+ Integer.parseInt(pubTestCaseID) + " AND IterationNumber= "
							+ Integer.parseInt(pub_Cur_Iteration) + ")";
					log.info(strQuery);
				
					JSONArray rsobj= RestApicall(strQuery);					
					if (rsobj.length() > 0) {
						JSONObject rs3 = rsobj.getJSONObject(0);	
						Dynamic_TestValue = rs3.getString("InputData");
					} else {
						Dynamic_TestValue = "";
					}			
    			}						
			}

			WebElement e1 = driver.findElement(By.id(TableID));

			List<WebElement> rows_tbody = e1.findElements(By.tagName("tbody"));
			List<WebElement> rows_table = rows_tbody.get(0).findElements(By.tagName("tr"));
			int rows_count = rows_table.size();

			for (int row = 0; row < rows_count; row++) {

				List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
				WebElement e3;
				String Dynamic_No = "";
				if (Dynamic_Field.equals("1")) {
					e3 = Columns_row.get(Dynamic_ColumnIndx).findElement(By.tagName("input"));
					Dynamic_No = e3.getAttribute("value");
				} else {
					Dynamic_No = Columns_row.get(Dynamic_ColumnIndx).getText();
				}
				if (Dynamic_TestValue.contains(Dynamic_No.trim())) {
					WebElement e2 = Columns_row.get(ColumnIDX).findElement(By.tagName("input"));
					e2.click();
					break;
				}
			}
		} catch (Exception ex) {
			// log.info("Table error "+ex.getMessage());
		}
	}
	public void Get_EnvironmentValue(String dyn_Key) {
		try {
			/**************************************************************************/
			String envQuery = "select EnvironmentValue from tbl_EnvironmentVariables where EnvironmentID = '"
					+ pub_TDEnvID + "' and EnvironmentName = '" + dyn_Key + "'";
			JSONArray jsondata= RestApicall(envQuery);					
			if (jsondata.length() > 0) {	
				JSONObject rs = jsondata.getJSONObject(0);	
				Dynamic_TestValue = rs.getString("EnvironmentValue");
			} else {
				Dynamic_TestValue = "";
			}
			/**************************************************************************/
		} catch (Exception ex) {
			Loggerupdator("Failed to get EnvironmentValue "+dyn_Key ,"Get_EnvironmentValue",0,ex.toString());			
		}
	}



	public static void employeelisttable(String tableid, int tableValueIdx, int tableRadioIdx, String TableValue) {
		try {
			WebElement e1;
			e1 = driver.findElement(By.xpath(tableid));

			List<WebElement> rows_tbody = e1.findElements(By.tagName("tbody"));
			List<WebElement> rows_table = rows_tbody.get(0).findElements(By.tagName("tr"));
			// To calculate no of rows In table.
			int rows_count = rows_table.size();

			for (int row = 0; row <= rows_count; row++) {
				List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName("td"));
				int columns_count = Columns_row.size();
				if (tableValueIdx <= columns_count) {
					System.out.println("Number of cells In Row " + row + " are " + columns_count);
					String celltext = Columns_row.get(tableValueIdx).getText().toString();
					if (celltext.equalsIgnoreCase(TableValue)) {
						Columns_row.get(tableRadioIdx).findElement(By.tagName("a")).click();
						;
						break;
					}
				}

			}
		} catch (Exception ex) {

		}
	}

	public void ExecutionStepsInDB(String KeywordName, String testData, String ExpectedData, String ActualTestDataValue,
			String strStatus, String lnkScreenshotImg, String ObjectID, int SubIteration, String eventType,
			String Curr_Time, String Cur_TestStepDesc, boolean screenshotflag, int dyn_flg) {
		
		String Execution_Step_Qry="";
		try {
			
			/**************************************************************************/
			
			if(screenshotflag){
				Execution_Step_Qry = "INSERT INTO tbl_ExecutionTCSteps(ExecutionID,IterationID,ObjectName,ObjectDesc,InputData,ExpectedData,ActualData,EventType,Status,ExecutionTime,ImagePath,DynamicFlag,Object_ID,SubIteration_ID) ";
				Execution_Step_Qry += " VALUES(" + Env_TestcaseExecutionID + "," + pub_Cur_Iteration + ",'" + KeywordName
						+ "','" + Cur_TestStepDesc + "','" + testData + "','" + ExpectedData + "','" + ActualTestDataValue
						+ "','" + eventType + "','" + strStatus + "','" + Curr_Time + "','" + lnkScreenshotImg + "','"
						+ dyn_flg + "','" + ObjectID + "'," + SubIteration + ") ";
				
			}else{			
				Execution_Step_Qry = "INSERT INTO tbl_ExecutionTCSteps(ExecutionID,IterationID,ObjectName,ObjectDesc,InputData,ExpectedData,ActualData,EventType,Status,ExecutionTime,DynamicFlag,Object_ID,SubIteration_ID) ";
				Execution_Step_Qry += " VALUES(" + Env_TestcaseExecutionID + "," + pub_Cur_Iteration + ",'" + KeywordName
						+ "','" + Cur_TestStepDesc + "','" + testData + "','" + ExpectedData + "','" + ActualTestDataValue
						+ "','" + eventType + "','" + strStatus + "','" + Curr_Time + "','" + dyn_flg + "','" + ObjectID + "'," + SubIteration + ") ";			
			}		
			
			RestApicall(Execution_Step_Qry);
			/**************************************************************************/
		} catch (Exception ex) {
			Loggerupdator("Failed to update the Execution steps into DB Server: "+Execution_Step_Qry,"ExecutionStepsInDB",0,ex.toString());			
		}
	}

	public void ReportTestplan(String TestcaseDescription, String ExpectedResult, String ActualResult,
			String TestcaseStatus, String TestDatasDescription, String TestDatas, String testcasesubid) {
		try {
			int ExecutionId = Env_TestcaseExecutionID;
			int TestcaseId = Integer.parseInt(pubTestCaseID);
			String iterations = pub_Cur_Iteration;
			int appId = Integer.parseInt(PubApplicationID);
			String Testdatas = "";

			if (TestDatas != "" && TestDatasDescription != "") {
				String[] Testdata = TestDatas.split(",");
				String[] TestdataDescription = TestDatasDescription.split(",");
				int i = 0;
				for (String data : Testdata) {
					String GetData = "";
					if (data.toUpperCase().startsWith("DYN_")) {
						Get_DynamicValue(data);
						GetData = Dynamic_TestValue;
					} else if (data.toUpperCase().startsWith("ENV_")) {
						Get_EnvironmentValue(data);
						GetData = Dynamic_TestValue;
					} else {
						/**************************************************************************/
						String qry = "select objID from tbl_Objects where KeywordName  = '" + data
								+ "' and ApplicationID = " + appId + "";					
						JSONArray jsondata=RestApicall(qry);													
						if (jsondata.length() > 0) {
							JSONObject rs1 = jsondata.getJSONObject(0);
							int Cur_objectId = rs1.getInt("objID");
							GetData=fnGetTestData(String.valueOf(Cur_objectId),String.valueOf(iterations));							
						} else {
							System.out.println("Error");
						}
						/**************************************************************************/
					}
					Testdatas += TestdataDescription[i] + " : " + GetData + "\r\n";
					i++;

				}
			}
			/**************************************************************************/
			String TestplanQry = "INSERT INTO tbl_ReportTestplan(ExecutionID,TestcaseID,TestcaseDescription,RunID,GroupName,IsIntegration,ModuleName,ExpectedResult,ActualResult,TestcaseStatus,TestDatas,TestcaseSubID) ";
			TestplanQry += " VALUES(" + Env_TestcaseExecutionID + "," + TestcaseId + ",'" + TestcaseDescription + "',"
					+ Pub_ExecutionRequestId + ",'" + pub_IntegrationGrpName + "','" + pub_IsIntegrationTC + "','"
					+ pub_SubModuleName + "','" + ExpectedResult + "','" + ActualResult + "','" + TestcaseStatus + "','"
					+ Testdatas + "','" + testcasesubid + "') ";
			RestApicall(TestplanQry);
			/**************************************************************************/
		} catch (Exception ex) {
			Loggerupdator("Failed to update ReportTestplan","ReportTestplan",0,ex.toString());			
		}
	}

	public void fnPdfDownload() {

		InternetExplorerDriver ieDriver = null;
		try {

			Thread.sleep(4000);
			;
			// String window ="";
			String CurrenWindowName = "";
			for (String winHandle : driver.getWindowHandles()) {

				CurrenWindowName = winHandle;

			}

			driver.switchTo().window(CurrenWindowName);
			Thread.sleep(3000);
			Robot robot = new Robot();
			robot.mouseMove(630, 600); // move mouse point to specific location
			robot.delay(1500); // delay is to make code wait for mentioned
								// milliseconds before executing next step
			robot.mousePress(InputEvent.BUTTON3_DOWN_MASK); // press left click
			robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK); // release left
																// click
			robot.delay(1500);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.delay(1500);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyRelease(KeyEvent.VK_DOWN);
			robot.delay(2000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.delay(5000);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.delay(2000);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.delay(2000);
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			robot.delay(2000);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			;
			String home = System.getProperty("user.home");
			File theNewestfile = null;
			File dir = new File(home + "/Downloads");
			log.info("XLSX FILE2 ");
			FileFilter fileFiler = new WildcardFileFilter("*.PDF");
			log.info("XLSX FILE3 ");
			;
			File[] files = dir.listFiles(fileFiler);
			log.info("XLSX FILE4 " + files.length);
			if (files.length > 0) {
				log.info("XLSX FILE5 ");
				Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
				theNewestfile = files[0];
				log.info("XLSX FILE " + theNewestfile.getName());

				String filename = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
				log.info("Date File Name " + filename);

				if (theNewestfile.renameTo(
						new File("\\\\10.138.80.50\\Bank\\QRator\\Documents\\ProjectJewel_Templates\\Downloads\\"
								+ filename + "_" + theNewestfile.getName()))) {
					Thread.sleep(4000);
					String CSVfilePath = "\\\\10.138.80.50\\Bank\\QRator\\Documents\\ProjectJewel_Templates\\Downloads\\"
							+ filename + "_" + theNewestfile.getName();
					sno++;
					result("Downloaded File", CSVfilePath, "Pass", "0", 0, "Click");
					// pdffile = CSVfilePath;
				}
			}

		}

		catch (Exception e) {
			e.getMessage();
		}

	}

	public void LOADINGICON(String TableXpath) {
		try {
			for (int i = 0; i < 60; i++) {
				Thread.sleep(2000);

				boolean ele_size = driver.findElement(By.xpath(TableXpath)).isDisplayed();
				if (ele_size == false) {
					break;
				}
			}

		} catch (Exception e) {
		}
	}

	public void fnUpload() {
		InternetExplorerDriver ieDriver = null;
		try {

			Thread.sleep(4000);
			// ;
			// String window ="";
			String CurrenWindowName = "";
			for (String winHandle : driver.getWindowHandles()) {

				CurrenWindowName = winHandle;

			}
			String Filename = "D:\\Abirami\\Quantify\\Demo_Banking_Feb2019_6.jmx";

			// driver.switchTo().window(CurrenWindowName);
			StringSelection ss = new StringSelection(Filename);
			// Toolkit.getDefaultToolkit().getSystemClipboard().getContents(ss);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
			Robot robot = new Robot();
			// robot.mouseMove(202,664); // move mouse point to specific
			// location
			// robot.delay(1500); // delay is to make code wait for mentioned
			// milliseconds before executing next step
			// robot.mouseMove(630, 600); // move mouse point to specific
			// location
			robot.delay(1500); // delay is to make code wait for mentioned
								// milliseconds before executing next step
			// robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // press left
			// click
			// robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			Thread.sleep(300);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

			// uploadelement.sendKeys("D:\\Abirami\\Quantify\\BankApplication_2019.jmx");
			Thread.sleep(100);

		}

		catch (Exception e) {
			e.getMessage();
		}
		// TODO Auto-generated method stub

	}

	public void fnFullScreenshot() {
		// driver.manage().window().maximize();
		// driver.get("https://www.amazon.sg/?tag=googlepcabksg-22&hvadid=384481684545&hvpos=1t1&hvnetw=g&hvrand=2826273995825050190&hvpone=&hvptwo=&hvqmt=e&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9062531&hvtargid=kwd-10573980&ref=pd_sl_72dcplo99p_e");
		// take screenshot of the entire page
		Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000))
				.takeScreenshot(driver);
		try {
			ImageIO.write(screenshot.getImage(), "PNG",
					new File("C:\\Test_Fullscreenshot//Screenshot_Full_ff_test.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/// ############################################################################
	/// FUNCTION TO USE THE RETRIVE THE OBJECT MAPPING FOR ENABLE AND DISABLE
	/// FUCNTIONALITIES
	/// ############################################################################
	public void loadTestcaseObjectEnaDisable() {
		try {
			// Get Values
			/**************************************************************************/
			String qryGetObjectsEnDisable = "select [ID],[Keyword_ID],[Screenshot_Flag],[Testcase_ID],[Object_ID],[Product_ID],Row_Number() Over (partition by [object_id] order by id) as Sub_Iteration from tbl_Testcase_Keyword_EnableDisable where Testcase_Id = "
					+ Integer.parseInt(pubTestCaseID) + " and Product_Id = " + Integer.parseInt(ProductID)
					+ " order by ID";
			JSONArray jsondata= RestApicall(qryGetObjectsEnDisable);	
			for (int i = 0; i <= jsondata.length() - 1; i++) {
		
				JSONObject rs = jsondata.getJSONObject(i);
				String strObjectMap = rs.getString("Object_Id") + "_" + rs.getString("Sub_Iteration");
				String strObjEnDisablekeyword = rs.getString("Screenshot_Flag");
				if (strObjEnDisablekeyword == null || strObjEnDisablekeyword == ""
						|| strObjEnDisablekeyword == "null") {

					TestStepObjectEnDisable.put(strObjectMap, "");
				} else {
					TestStepObjectEnDisable.put(strObjectMap, strObjEnDisablekeyword);
				}		
			}
			/**************************************************************************/
		}
		catch (Exception e) {
			Loggerupdator("Failed to update loadTestcaseObjectEnaDisable","loadTestcaseObjectEnaDisable",0,e.toString());			
		}
	}

	public String fnCheckIfObjectIsEnableDisable(String strEventType, String strObjectID, int strSubIterationID) {

		String strReturn = "";
		try {
			String strOptVal = "";
			if (strEventType == "CLICK") {
				// Checking if no of occurrences available
				int strOccurrences = Collections.frequency(TestStepListED, strObjectID);

				strOptVal = strObjectID + "_" + String.valueOf(strOccurrences + 1);
				// Check if Key is exist or not
				if (TestStepObjectEnDisable.containsKey(strOptVal)) {
					strReturn = TestStepObjectEnDisable.get(strOptVal);
				} else {
					strReturn = "0";
				}

				// Add to List
				TestStepListED.add(strObjectID);
			} else {
				strOptVal = strObjectID + "_" + String.valueOf(strSubIterationID);
				// Check if Key is exist or not
				if (TestStepObjectEnDisable.containsKey(strOptVal)) {
					strReturn = TestStepObjectEnDisable.get(strOptVal);
				} else {
					strReturn = "0";
				}
			}
		} catch (Exception e) {
			Loggerupdator("Failed to update fnCheckIfObjectIsEnableDisable","fnCheckIfObjectIsEnableDisable",0,e.toString());			
		}
		return strReturn;
	}

	public static List<String> StartTransaction(String KeywordName) {

		List<String> Data = null;
		try {
			long starvalue = System.currentTimeMillis();
			Data = new ArrayList<String>();
			Data.add(KeywordName + "###" + starvalue);

		} catch (Exception e) {
			System.out.println("StartTransaction :: " + e);
		}
		return Data;
	}

	public static void EndTransaction(List<String> Data) {

		try {
			long EndTimeUtills = System.currentTimeMillis();
			String keywordName = Data.get(0).split("###")[0];
			long StartTimeUtills = Long.parseLong(Data.get(0).split("###")[1]);
			long total = EndTimeUtills - StartTimeUtills;

			List<List<Object>> batteryinfo = ((HasSupportedPerformanceDataType) AndroidDriver)
					.getPerformanceData("com.starhub.giga", "batteryinfo", 1);
			//
			List<List<Object>> memoryinfo = ((HasSupportedPerformanceDataType) AndroidDriver)
					.getPerformanceData("com.starhub.giga", "memoryinfo", 1);

			List<List<Object>> networkinfo = ((HasSupportedPerformanceDataType) AndroidDriver)
					.getPerformanceData("com.starhub.giga", "networkinfo", 1);

			List<List<Object>> cpuinfo = ((HasSupportedPerformanceDataType) AndroidDriver).getPerformanceData("", "cpuinfo",
					1);

			_Battery_Max = Integer.parseInt(batteryinfo.get(1).get(0).toString());

			_Networ_Down = Integer.parseInt(networkinfo.get(networkinfo.size() - 1).get(3).toString());

			_Mem_Heap = Integer.parseInt(memoryinfo.get(1).get(11).toString());

			_Mem_Heap_1 = Integer.parseInt(memoryinfo.get(1).get(10).toString());

			_CPU_Max = Double.parseDouble(cpuinfo.get(1).get(0).toString())
					+ Double.parseDouble(cpuinfo.get(1).get(1).toString());

			double bat_avg = (_Battery_Max + _Battery_Min) / 2;
			double Net_avg = (_Network_Up + _Networ_Down) / 2;

			double temp = 0;

			if (_Battery_Min > _Battery_Max) {
				temp = _Battery_Max;
				_Battery_Max = _Battery_Min;
				_Battery_Min = temp;
			}

			if (_Networ_Down > _Network_Up) {
				temp = _Network_Up;
				_Network_Up = _Networ_Down;
				_Networ_Down = temp;
			}

			if (_CPU_Min > _CPU_Max) {
				temp = _CPU_Max;
				_CPU_Max = _CPU_Min;
				_CPU_Min = temp;
			}

			FileWriter(StartTimeUtills, total, keywordName, bat_avg, _Battery_Max, Net_avg, _Network_Up, _Mem_Heap,
					_Mem_Heap_1, _CPU_Max, _CPU_Min);
			Data.clear();
		} catch (Exception e) {
			System.out.println("EndTransaction :: " + e);
		}

	}

	
	public void Loggerupdator(String info, String fun,int count, String error) {

		try {
			String str = "";
			str +="\n";
			 if (count == 0) {				
				str += "=================================================================== \n";
				str += "** INFO : " + info + " **\n";
				str += "=================================================================== \n";
				str += "\n";
			
				str += "=================================================================== \n";
				str += "** Function Name : " + fun + " **\n";
				str += "=================================================================== \n";
				str += "\n";
				
				str += "**************** FIND BELOW ERROR ************** \n";
				str += "=================================================================== \n";
				str += "** ERROR : " + error + " **\n";
				str += "=================================================================== \n";
				log.error(str);
			 }if (count == 1) {
				str += "=================================================================== \n";
				str += "** INFO : " + info + " **\n";
				str += "=================================================================== \n";
				log.info(str);
			 }if (count == 2) {
			   str += "INFO : " + info + "";
			   log.info(str);
			}
			System.out.println(str);
		} catch (Exception ex) {
		}
	}
	
	private static void FileWriter(long startTimeUtills, long total, String keywordName, double bat_avg,
			double _Battery_Max2, double Net_avg, double _Network_Up2, double _Mem_Heap2, double _Mem_Heap_12,
			double _CPU_Max2, double _CPU_Min2) {

		try {
			if (TimestampHeaderCount == 1) {
				File file = new File("C:\\Automation\\config\\" + DeviceName + ".jtl");
				if (file.createNewFile()) {
					PrintWriter writer = new PrintWriter(file);			
					writer.close();
				} else {
					PrintWriter writer = new PrintWriter(file);				
					writer.close();
				}
			}
			double cpu_avg = 0;// (_CPU_Min+_CPU_Max) / 2;
			double roundOff = 0;// Math.round(cpu_avg * 100.0) / 100.0;

			BufferedWriter writer = Files.newBufferedWriter(Paths.get("D:\\PerformanceTesting\\" + DeviceName + ".jtl"),
					StandardOpenOption.APPEND);
			if (TimestampHeaderCount == 1) {
				writer.write(
						"timeStamp,elapsed,label,responseCode,responseMessage,CPUavg,Networkmax,success,Networkavg,Memoryavg,Memorymax,CPUmax,allThreads,BatteryAvg,DeviceName,DevicePlatform,BatteryMax,OSVersion");

				writer.write("\r\n");
				writer.write("" + startTimeUtills + "," + total + "," + keywordName
						+ ",200,OK," + _CPU_Max + "," + _Network_Up + ",true," + Net_avg + "," + _Mem_Heap + ","
						+ _Mem_Heap_1 + "," + roundOff + ",1," + bat_avg + "," + DeviceName + "," + DevicePlatForm + ","
						+ _Battery_Max2 + ",9.0");

				writer.write("\r\n");
				writer.close();
			} else {
				writer.write("" + startTimeUtills + "," + total + "," + keywordName
						+ ",200,OK," + _CPU_Max + "," + _Network_Up + ",true," + Net_avg + "," + _Mem_Heap + ","
						+ _Mem_Heap_1 + "," + roundOff + ",1," + bat_avg + "," + DeviceName + "," + DevicePlatForm + ","
						+ _Battery_Max2 + ",9.0");

				writer.write("\r\n");
				writer.close();
			}
			TimestampHeaderCount++;
		} catch (Exception e) {
			System.out.println(e);
		}
	}
		public void Isalertpresent_verify(String testdata){
		
		try{
			
			ActualTestDataValue = "Alert";
			// Thread.sleep(5000);
			log.info("Before alert");
			Alert alert = driver.switchTo().alert();
			System.out.println(alert.getText());
			log.info("Checking alert");
			String AlertText1 = alert.getText();
			//log.info(ActualTestDataValue);
			//alert.accept();
			
			if (testdata.equals(AlertText1)) {
				
				sno++;
				tsStatus = "Pass";
				result("Alert_Message", AlertText1, "Done", "0", 0, "Click");			
			}
			else{	
			sno++;
			tsStatus = "Fail";
			result("Alert_Message", AlertText1, "Done", "0", 0, "Click");	
			}
			log.info("Alert is performed");
			ActualTestDataValue = "";
			// return true;
			String CurrenWindowName1 = "";

			for (String winHandle : driver.getWindowHandles()) {
				CurrenWindowName1 = winHandle;
				log.info("789REsultError4567  " + CurrenWindowName1);
			}
			driver.switchTo().window(CurrenWindowName1);
		} catch (Exception e) {
			
			sno++;
			tsStatus = "Fail";
			result("Alert_Message", e.getMessage(), "Done", "0", 0, "Click");	
		}	
	}
		
	public JSONArray RestApicall(String Query) {
		JSONArray array;
		try {
			String URL = Apiservice + "/FrameworkAPI/QueryExe?query=" + Query;
			Response res = RestAssured.get(URL);
			int code = res.getStatusCode();
			if (code == 200) {
				array = new JSONArray(res.asString());
				return array;
			} else {
				return new JSONArray("[]");
			}
		} catch (Exception ex) {
			Loggerupdator("Error Response API Service Query Execution : "+Query,"RestApicall",0,ex.toString());			
			return new JSONArray("[error]");
		}
	}
	
	public String GetQueryReturn_1(String Dynamic_Keyword, int DataSubIteration) {
		try {

			String Dynamic_TestValue = "";

			String strQuery = "";
	
			if (Dynamic_Keyword.toUpperCase().startsWith("DYN_")) {
				String Dyn_TestcaseName = pubTestCaseName;
				if (Dynamic_Keyword.contains("&&")) {
					String[] Get_DynValues = Dynamic_Keyword.split("&&");
					Dynamic_Keyword = Get_DynValues[0];
					Dyn_TestcaseName = Get_DynValues[1];
				}
				strQuery = "Select COL_DYNAMIC_VALUE from TBL_DYNAMICDATA where COL_VARIABLETYPE = 'DYNAMICDATA' and COL_DYNAMIC_VARIABLE = '"
						+ Dynamic_Keyword + "' and COL_ITERATION = '" + pub_Cur_Iteration + "' and COL_TESTCASENAME = '"
						+ Dyn_TestcaseName + "' order by col_sno desc";
			
				JSONArray jsondata= RestApicall(strQuery);			

				if (jsondata.length() > 0) {
					JSONObject rs = jsondata.getJSONObject(0);		
					Dynamic_TestValue = rs.getString("COL_DYNAMIC_VALUE");
					if (Dyn_TestcaseName.equals("TS_CMN_BS032_BILLING_SEARCH_BILL_NO")) {
						Dynamic_TestValue = Dynamic_TestValue.split(" ")[0].trim();
					} else if (Dynamic_Keyword.equals("DYN_Main_BllDt_IBill_Info_LBL_BillNo")) {
						Dynamic_TestValue = Dynamic_TestValue.split(" ")[0].trim();
					}
				} else {
					Dynamic_TestValue = "";
				}

			} else if (Dynamic_Keyword.toUpperCase().startsWith("KEY_")) {
				Dynamic_Keyword = Dynamic_Keyword.replace("KEY_", " ");
				String qryGetTestData = "SELECT objid from tbl_objects where Applicationid="
						+ Integer.parseInt(PubApplicationID) + " and keywordname='" + Dynamic_Keyword + "'";
				
				JSONArray jsondata= RestApicall(qryGetTestData);					
				if (jsondata.length() > 0) {
					JSONObject rs = jsondata.getJSONObject(0);		
					strQuery = "SELECT * FROM tbl_IterationMapping WHERE objid="
							+ Integer.parseInt(rs.getString("ObjID")) + " and testcaseid = "
							+ Integer.parseInt(pubTestCaseID)
							+ " AND iterationid = (SELECT IterationId FROM tbl_Iteration WHERE TestcaseID= "
							+ Integer.parseInt(pubTestCaseID) + " AND IterationNumber= "
							+ Integer.parseInt(pub_Cur_Iteration) + ") and subIterationId= " + DataSubIteration + "";				
					JSONArray jsondata1= RestApicall(strQuery);	
					for (int i = 0; i <= jsondata1.length() - 1; i++) {					
						JSONObject rs1 = jsondata1.getJSONObject(i);		
						Dynamic_TestValue = rs1.getString("InputData");
					}
				}
			} else {
				strQuery = "SELECT * FROM tbl_IterationMapping WHERE objid=(SELECT TOP 1 objid from tbl_objects where Applicationid="
						+ Integer.parseInt(PubApplicationID) + " and keywordname='" + Dynamic_Keyword
						+ "') and testcaseid = " + Integer.parseInt(pubTestCaseID)
						+ " AND iterationid =(SELECT TOP 1 IterationId FROM tbl_Iteration WHERE TestcaseID= "
						+ Integer.parseInt(pubTestCaseID) + " AND IterationNumber= "
						+ Integer.parseInt(pub_Cur_Iteration) + "  AND ProductNameID = " + Integer.parseInt(ProductID)
						+ ")and subIterationId= " + DataSubIteration + "";
				
				JSONArray jsondata1= RestApicall(strQuery);			
				for (int i = 0; i <= jsondata1.length() - 1; i++) {					
					JSONObject rs1 = jsondata1.getJSONObject(i);		
					Dynamic_TestValue = rs1.getString("InputData");
				}
			}
			return Dynamic_TestValue;
		} catch (Exception ex) {
			Loggerupdator("Could not get GetQueryReturn_1 Data","GetQueryReturn_1",0,ex.toString());			
			return "";
		}
	}
}